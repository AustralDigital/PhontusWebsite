# Handoff: Phontus marketing site rebuild

## Overview

A full redesign of phontus.live — eleven pages covering the product, how it works, four industry solutions, security, about, contact, and three legal pages. It replaces the current site with a layout and voice built on the Phontus Design System, drawing structural cues (oversized headlines, eyebrow labels, numbered steps, logo marquee, FAQ accordion, dark pre-footer band, scroll-reveal) from the Brim Webflow template the client referenced.

The product story the site tells, which the current site gets wrong in one important respect: **the kits no longer use headsets.** Each kit has an external directional microphone that isolates the two people speaking and rejects the room around them. Both people talk out loud. Nothing is handed over, worn, or cleaned between conversations. This is load-bearing copy — it appears in the hero, step 02 of How it works, both kit descriptions, and three FAQs. Do not reintroduce headset language.

## About the design files

The files in `design/` are **design references created in HTML** — a prototype showing intended look and behaviour, not production code to copy. `Phontus Website.dc.html` is a single-file React prototype rendered by a bespoke design runtime (`support.js`), with all styling inline and page switching handled in component state. It is not a shippable website.

**The task is to recreate these designs in the target codebase.** phontus.live is a Next.js app (its markup shows `/_next/image` URLs), so the natural target is the existing Next.js project, using its established component patterns, styling approach and image pipeline. The prototype's inline styles are an artefact of the design tool, not a recommendation — map them onto the codebase's existing convention (CSS modules, Tailwind, styled-components, whatever is already there).

Two things in the prototype exist only to work around the design runtime and should **not** be carried across:

1. **Page routing is component state.** `this.state.page` plus a chain of `<sc-if>` blocks. In Next.js these become real routes (map below). Real routes are the single most important upgrade — the prototype has one URL, so search engines and social cards see one page.
2. **Scroll reveal is JS-driven with a `data-hide` attribute and a 250ms polling interval.** The prototype avoids IntersectionObserver and opacity transitions because both are unreliable in the design preview environment. In a real browser, use IntersectionObserver and CSS. Keep the one design decision behind it: **the entrance is transform-only, never an opacity fade**, so text can never be stuck invisible if motion fails to run.

## Fidelity

**High-fidelity.** Final colours, typography, spacing, copy and interaction behaviour. Recreate the UI faithfully, using the Phontus Design System tokens as the source of truth rather than reading values out of the prototype's inline styles. Every colour, type step, radius, shadow and spacing value in the prototype resolves to a token in `design/_ds/tokens/`.

The exception is **photography**: there is none. Nine image placeholders are drop targets awaiting real photos (listed under Assets).

---

## Route map

The prototype's `page` state values map to routes as follows. The `tab` state on the product page should be a URL parameter or hash so a product tab is linkable.

| State | Route | Page title (h1) |
| --- | --- | --- |
| `home` | `/` | Make everyday conversations easier to understand |
| `product` | `/product` | One interpreting service. Three ways in, and the parts that hold it together. |
| `product` + `tab=clinical\|frontline\|phone\|human\|console` | `/product?tab=…` | (tab panels — see Product page) |
| `how` | `/how-it-works` | A conversation, from the moment someone walks up. |
| `solutions` | `/solutions` | The conversations that happen before anything else can. |
| `health` | `/solutions/healthcare` | Care that starts on time. |
| `ops` | `/solutions/business-operations` | Work that cannot wait for a callback. |
| `schools` | `/solutions/education` | Families reached the first time. |
| `hotels` | `/solutions/hospitality` | Service that does not need a translator app. |
| `security` | `/security` | Security is a practice, not a claim. |
| `about` | `/about` | Language barriers should not slow service down. |
| `contact` | `/contact` | Tell us where language comes up. |
| `privacy` | `/privacy` | Privacy |
| `terms` | `/terms` | Terms of service |
| `accessibility` | `/accessibility` | Accessibility |

The existing site's solution URLs (`/solutions/healthcare`, `/solutions/business-operations`, `/solutions/education`, `/solutions/hospitality`) are preserved above so existing links and any SEO equity survive.

---

## Global chrome

### Sticky header

- Sticky, `z-index: 40`, `background: rgba(255,255,255,.86)` with `backdrop-filter: saturate(180%) blur(12px)`, `border-bottom: 1px solid --border-subtle`. This blur and the modal scrim are the only two blurs sanctioned by the design system.
- Inner bar: max-width 1200px, `padding: 0 clamp(20px,4vw,40px)`, `display:flex`, `gap:40px`, height **72px**, condensing to **60px** once scrolled past 40px, with `transition: height 220ms var(--ease-standard)`.
- Logo: `assets/phontus-lockup.svg`, height 24px, links to `/`.
- Nav links: `--weight-medium`, `--text-sm`, `--text-secondary`, hover `--green-950`. Items: Product, How it works, Solutions, Security, About. Contact and the primary CTA sit right-aligned.
- **Active page indicator**: a 2px `--gradient-rule` bar under the current nav item, `bottom:-26px`, full width of the link. The four solution pages all light the Solutions item.
- **Scroll progress rule**: 2px full-bleed `--gradient-rule` bar at the header's bottom edge, width = scroll percentage. The design system names `--gradient-rule` for progress tracks specifically, which is why this is the sanctioned place to use it.

### Mega menus (desktop only, >900px)

Open on `mouseenter` of Product and Solutions; close on header `mouseleave`. Panel is a white band below the header, containing a hairline tile grid: an outer wrap (max-width 1200px, `padding: 24px 40px 28px`) and an inner grid with **no padding** carrying `gap:1px; background:--border-subtle; border:1px solid --border-subtle`. That two-element split is what makes the rules read as hairlines rather than a grey slab — do not merge the padding onto the grid element.

- **Product menu: exactly three tiles** — Clinical Kit, Frontline Kit, Phone Line. Human interpreter escalation and the admin console are deliberately **not** in this menu; listing them made five things look like five products when there are three. Each tile deep-links to the product page with that tab selected.
- **Solutions menu: four tiles** — one per solution page.
- Both menus must be disabled below 900px. Hover has no touch equivalent, and leaving them in strands seven destinations.

### Mobile navigation (≤900px)

Nav and CTA are replaced by a 44px hamburger button (`menu` / `x` icon). It opens a full-screen white panel, `position:fixed; top:72px; bottom:0`, that scrolls internally, with body scroll locked while open. Contents: five page links (Home, How it works, Security, About, Contact) at `--text-lg`/600 with hairline dividers, then a "Product" group (three products), then a "Solutions" group (four pages), then a full-width primary CTA. Twelve destinations total.

Two implementation notes learned the hard way:

- **The overlay must not be a descendant of the header.** The header's `backdrop-filter` makes it a containing block for `position:fixed` children, which collapsed the overlay to zero height.
- **The header must not condense while the menu is open**, or a strip of page content shows between the 60px header and the overlay's 72px offset.

### Deep-green CTA band (all pages)

`background: var(--gradient-band)` — the deep green lit from one corner by the signal gradient. Centred: 56px bridge mark, h2 at `clamp(30px,4.6vw,48px)`/800/`--tracking-tighter`, lead at `rgba(255,255,255,.72)`, then an accent (yellow) primary button and an inverse secondary. `padding: clamp(64px,9vw,104px) clamp(20px,4vw,40px)`.

**This is the site's one gradient moment per page**, per the design system's "one gradient moment per screen" rule, and the only deep-green band. The home hero additionally carries `--gradient-whisper`, a barely-there bloom; inner-page heroes are flat white so the band stays the single moment.

### Footer

`--neutral-50`, hairline top border. Columns: brand blurb + email, then Product, Solutions, Company, Trust. Then a bottom bar with `© 2026 Phontus, Inc.` and `Spanish ⇄ English at launch`. Privacy, Terms and Accessibility link to the three legal pages.

### Custom cursor

The native cursor is hidden site-wide and replaced by a 28px circle filled with `--gradient-signal` at **35% opacity**, following the pointer, scaling to 1.7× over links, buttons, tabs, fields and image slots.

Implementation notes: hiding the native cursor needs `cursor: none !important` on a root attribute selector *and* a descendant selector — a UA rule gives `a` a pointer, and the design system's `Button` sets `cursor` inline, so neither is beaten by an inherited value or an unweighted rule. Text inputs keep `cursor:auto` so typing reads correctly. Gate the whole thing on `(hover:hover) and (pointer:fine)` so touch devices never get a phantom circle.

**Please make a deliberate decision about keeping this.** It's a nice piece of craft, but this is a product whose premise is accessibility, and overriding the system cursor is exactly the kind of thing that hurts some users. The prototype has a toggle; production should probably respect a preference or drop it.

---

## Pages

### Home (`/`)

Sections in order:

1. **Hero** — centred. Eyebrow "Say it in your own language" (11px overline, `--tracking-caps`, `--green-700`, preceded by a 22×2px `--gradient-rule` dash — this eyebrow pattern repeats on every section on the site). H1 "Make everyday conversations easier to understand" at `clamp(40px,7.4vw,76px)`/800/`--tracking-tighter`/`line-height:1.02`, max-width 900px, `text-wrap:balance`. Lead: "Start a session, speak naturally, communicate. Phontus interprets Spanish and English out loud, in real time — at the front desk, in the exam room, on the phone." Two CTAs: primary "Request a demo" (→ contact), secondary "See how it works" (→ how-it-works). Then three tags: "Spanish ⇄ English at launch", "No headsets to hand out", "Human interpreter on request".
2. **Hero visual** — one bordered surface, `--radius-surface`, `--shadow-xl`, split two-up: a photo slot (kit in use) and a live session mock. `--shadow-xl` is reserved by the design system for modals and the marketing hero mock; this is that exception.
3. **Trust strip** — caption "Early field testing with clinical teams, including dental and women's health settings.", then a CSS marquee of six neutral logo plates (132×30px, `--neutral-200`) duplicated for seamless looping, `phontus-marquee 32s linear infinite`, masked at both edges. Caption below: "Early partners, named as our pilots go public."
4. **Three ways in** — three cards: Clinical Kit, Frontline Kit (photo slot each), Phone Line (a small built mock, not a photo). Numbered 01–03 in tabular figures.
5. **How it works** — three numbered steps in a hairline grid: confirm the two languages / speak out loud, one turn at a time / bring in a person if you need one.
6. **In the room** — text left, session mock right, with three checkmark benefits.
7. **The platform** — text left, four hairline rows right: human interpreter escalation, admin console, devices and kits, controlled access.
8. **Where it runs** — four industry tiles linking to the solution pages.
9. **Testimonials** — three quote cards, currently placeholder (see Placeholder content).
10. **Field notes** — three article teasers, currently placeholder.
11. **FAQ** — six accordion rows, sticky heading column on the left.

### Product (`/product`)

Hero, then a **five-tab** interface using the design system `Tabs` component (`variant="underline"`): Clinical Kit, Frontline Kit, Phone Line, Human interpreter, Admin console.

The first three are the products. The last two carry a `--green-50` badge reading **"Included with every session"** and open by stating it plainly — the escalation panel begins "Not a separate product and not a separate purchase." This framing is the whole point of the tab structure: the client's complaint about the old layout was that it made one service look like five products.

Each panel is a two-up: media or mock on one side, badge + h2 + lead + four checkmark specs on the other.

**Below 760px the tabs become an accordion**: each of the five names renders as a tappable row directly above its own panel, with a plus/minus. Five tabs cannot sit in a 360px row.

### How it works (`/how-it-works`)

Hero, then three large numbered rows, each a two-up of explanation and a live mock (language pair + start button / status indicator + audio meter / transcript turn + escalation button). Then a four-across → three-across comparison of where a conversation starts: Clinical Kit, Frontline Kit, Phone Line. **Three, not four** — a browser session is not a product and was removed throughout.

### Solutions (`/solutions`) and the four solution pages

The overview holds four alternating cards (text one side, photo slot the other), each linking to its page.

Each solution page runs the same seven sections, with content specific to the setting:

1. Hero — eyebrow "Solutions · <name>", h1, lead, recommended-product tags, "← All solutions" link, photo slot.
2. **Conversations this covers** — six items in a hairline grid.
3. **What we recommend** — two cards, each naming a product, its role ("In the room", "Before and after the visit") and *why* it fits.
4. **One exchange** — a four-turn transcript of a real conversation in Spanish and English, with a status header. Healthcare: a first-time patient at the front desk. Operations: confirming a delivery window. Schools: a registration question at the office window. Hospitality: a late check-out request.
5. **What changes on both sides** — two cards, one for the staff member, one for the visitor or caller.
6. **Questions** — three FAQs specific to that setting.
7. **Tuned CTA** — a light card with setting-specific copy and a demo button, before the shared green band.

> **Please have someone who has worked these desks read the four transcripts.** They are written, not recorded — plausible and on-voice, but not observed.

### Security (`/security`)

Hero, a 2×2 hairline grid (controlled access / secure transmission / session handling you set / nothing for a visitor to install), then a two-up: "Where we are today" and a list of what a security review would cover.

This page deliberately claims **no certifications**. It names who it's for — organisations that have to answer security questions before they can say yes — then describes what is in place, what is in progress, and what a review covers. Do not add SOC 2, HIPAA or GDPR badges until they are real; the design system's own marketing kit shows such tags, and they were removed here on purpose.

### About (`/about`)

Hero, "Where we started" (the dental and women's health field testing, and what those rooms taught us to remove), a 2×2 fact grid, then "What we will not compromise on" — four principles.

### Contact (`/contact`)

Two-up: left is the pitch plus a three-step "what happens next"; right is a form card (`--shadow-lg`) with first name, last name, work email, organization, a setting select, and a textarea. **The form does not submit anywhere** — it needs a real endpoint.

### Privacy, Terms, Accessibility

Single-column prose, max-width 820px, sections separated by hairline top borders, h2 at `--text-xl`/700.

**All three carry a visible amber review notice**, gated on the same flag as the other placeholder labels. Privacy and Terms additionally carry inline amber flags marking every item that needs company-specific facts: legal entity and jurisdiction, how session audio is handled, default retention period, the subprocessor list, whether kits are sold or leased, pricing and notice periods, any uptime commitment, and the whole liability and governing-law section.

**These are drafts, not legal advice.** They state honestly how the product is designed to work and are structured the way a reviewer expects, but they must go to counsel before publication. Notably, Terms includes a section on what AI interpreting is and is not — that it should not substitute for a certified human interpreter for consent, diagnosis or legal instruction — and a "not for emergencies" section. Those exist because this product is used in clinical settings, and they are worth keeping through review.

---

## Interactions & behaviour

| Behaviour | Detail |
| --- | --- |
| Page navigation | Sets page state, scrolls to top, closes any open menu. In production: real route navigation. |
| Mega menu | Opens on hover of Product/Solutions, closes on header mouseleave. Desktop only (>900px). |
| Mobile menu | Toggle button; body scroll locked while open; any link closes it. |
| Product tabs | `Tabs` `onChange` sets tab state. Deep-linked from the Product mega menu. Accordion below 760px. |
| FAQ accordions | One independent open/closed flag per row, plus/minus icon swap. Home has 6, each solution page 3. |
| Scroll reveal | Elements marked for reveal rise 8px into place, staggered 70ms apart within their section, capped at 280ms. Re-runs on page and tab change. Transform only — never opacity. |
| Header condense | 72px → 60px past 40px of scroll; stays 72px while the mobile menu is open. |
| Scroll progress | Gradient rule width tracks scroll depth 0–100%. |
| Card hover | Border steps `--border-subtle` → `--border-default`, shadow `--shadow-sm` → `--shadow-md`, 220ms. **No lift** — the design system forbids hover lifts except the session hero control. |
| Cursor | 28px gradient circle at 35% opacity, 1.7× over interactive elements, 140ms. |
| Session mocks | A 1.6s interval cycles listening → interpreting → speaking, driving the status indicator, audio meter, pending state on the second transcript turn, and a counting clock. Purely decorative; consider pausing when offscreen and respecting reduced-motion. |
| Reduced motion | `prefers-reduced-motion: reduce` zeroes reveal transitions. Extend this to the marquee and the session mock cycle in production. |

## Responsive behaviour

Built with intrinsic CSS (`repeat(auto-fit, minmax(min(100%, Npx), 1fr))` and `clamp()`) rather than media queries, because the design tool only supports inline styles. **In a real codebase, media queries are likely clearer** — but keep the resulting behaviour:

| Element | Desktop | Tablet (~768–1024) | Phone (≤760) |
| --- | --- | --- | --- |
| Four-across grids (min track 270px) | 4 | 2 | 1 |
| Three-across grids (min track 250px) | 3 | 2 | 1 |
| Two-across grids (min track 280px) | 2 | 2 | 1 |
| Two-column splits (min track 390px) | 2 | 1–2 | 1 |
| Footer columns (min track 168px) | 5 | 3 | 1 |
| Header | Full nav + mega menus | Hamburger below 900px | Hamburger |
| Product tabs | Underline tab strip | Tab strip | Accordion below 760px |

Fluid values: gutters `clamp(20px,4vw,40px)`; section rhythm `clamp(56px,8vw,96px)`; large gaps `clamp(28px,4vw,64px)`; hero h1 `clamp(40px,7.4vw,76px)`; page h1 `clamp(34px,5.6vw,60px)`; section h2 `clamp(30px,4.6vw,48px)`; sub-heads `clamp(26px,3.6vw,38px)`. Narrowest guaranteed width is **360px**.

## State

| State | Purpose |
| --- | --- |
| `page` | Which page is shown → becomes routing. |
| `tab` | Product page tab, one of clinical/frontline/phone/human/console → becomes a URL param. |
| `menu` | Which mega menu is open, or none. |
| `navOpen` | Mobile menu open. |
| `open{}` | Per-FAQ-row open flags. |
| `vw` | Viewport width, for the header and tab breakpoints → replace with CSS and a media-query hook. |
| `tick` | Session-mock animation counter. |

No data fetching. The only real backend need is the contact form.

## Design tokens

**Do not read values out of the prototype's inline styles.** Every one resolves to a token in `design/_ds/tokens/`, which is the source of truth: `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `gradients.css`, `motion.css`, `fonts.css`. The most-used, for orientation:

- **Green** `--green-50 #EDFCF6` · `--green-400 #28E5B0` · `--green-600 #0BA57B` (primary action) · `--green-700 #0B8465` (eyebrows, icons) · `--green-900 #1E4038` (the brand dark, the band) · `--green-950 #10251F` (**all headings and titles**)
- **Yellow** `--yellow-300 #FBCE50` — live/active and one emphasis action per screen. Never a background field, never body text on white; `--yellow-700` is the text-safe stop.
- **Neutrals, warm and slightly green-biased** — canvas `--neutral-50 #FAFAF7`, cards white, borders `--neutral-200`, body text `--neutral-700`/`--neutral-600`
- **Type** — Inter at the 28pt optical size, every weight. 800 display, 700 headings, 600 labels and buttons, 500 data, 400 body. Tabular figures for anything read as data: timers, session IDs, durations, the 01/02/03 numerals.
- **Radius** — 6 chips, 10 buttons and inputs, 14 cards, 20 modals and session panes, pill for status and round controls only.
- **Shadows** — green-tinted, low. `xs`/`sm` cover almost everything; `lg` for the contact form card; `xl` for the hero mock only.
- **Motion** — 140ms control feedback, 220ms panels, 360ms maximum. `--ease-standard: cubic-bezier(.32,.72,0,1)`.

## Design-system components used

From the bound Phontus Design System bundle (`design/_ds/_ds_bundle.js`, namespace `PhontusDesignSystem_6af7fc`): `Button`, `Badge`, `Tag`, `Icon`, `Input`, `Select`, `Textarea`, `Tabs`, `StatusIndicator`, `LanguagePair`, `TranscriptTurn`, `AudioMeter`.

If the codebase already has equivalents, use those. If not, these components carry real domain rules worth preserving — `StatusIndicator` is the single canonical definition of the ten session states, and `LanguagePair` enforces "languages in words, never flags".

Icons are [Lucide](https://lucide.dev) at **stroke width 1.75**, never below 1.5. Glyphs used: `languages`, `mic`, `audio-lines`, `user-round`, `phone-incoming`, `phone-off`, `arrow-right-left`, `arrow-right`, `tablet-smartphone`, `layout-dashboard`, `monitor-dot`, `shield-check`, `wifi`, `timer`, `users`, `check`, `plus`, `minus`, `menu`, `x`, `rotate-ccw`, `radio`, `heart-pulse`, `truck`, `graduation-cap`, `concierge-bell`, `triangle-alert`.

**No flags, no emoji.** The only non-icon glyphs in use are `⇄` for language direction and `·` as a metadata separator.

## Assets

Brand marks in `design/assets/`, copied from the design system: `phontus-lockup.svg` (header, footer), `phontus-lockup-white.svg` (for green and photographic backgrounds), `phontus-bridge.svg` (the mark alone — the green band and a session mock).

**Nine photo placeholders need real photography.** They render as drop targets in the prototype and are its biggest visual gap:

| ID | What it needs |
| --- | --- |
| `home-hero-kit` | Frontline Kit in use at a counter, two people talking |
| `home-clinical-kit` | Clinical Kit cart |
| `home-frontline-kit` | Frontline Kit on a counter |
| `home-post-1/2/3` | Three article images |
| `prod-clinical` | Clinical Kit at the point of care |
| `prod-frontline` | Frontline Kit on a service counter |
| `sol-health`, `page-health-hero` | Clinic reception or exam room |
| `sol-ops`, `page-ops-hero` | Counter, dock or install site |
| `sol-schools`, `page-schools-hero` | School front office window |
| `sol-hotels`, `page-hotels-hero` | Hotel reception desk |

Direction, per the design system: documentary and warm-neutral. Real rooms, real staff, natural light. No cool blue-teal grade, no stock-photo handshakes. **Photos must not show headsets.**

## Placeholder content to resolve before launch

All of it is honestly labelled in the prototype, and the labels are controlled by one flag so they clear together.

- **Logo marquee** — six neutral plates, no customer logos exist yet. Caption: "Early partners, named as our pilots go public."
- **Three testimonials** — quotes are plausible but unapproved, attributed to "Early pilot team". Badge: "From early field testing."
- **Three article teasers** — realistic titles marked "Coming soon".
- **Legal pages** — see above; amber flags mark every fact needing confirmation.

There are no invented statistics anywhere on this site. The client had none to give, so the proof sections are built to work without them. If metrics arrive later, the natural homes are the hero and the "Where we started" grid on About.

## Files

```
design/
  Phontus Website.dc.html   the whole design — all 11 pages, ~2,200 lines
  support.js                design-runtime; not part of the deliverable
  image-slot.js             photo placeholder component; not part of the deliverable
  assets/                   brand SVGs (do use these)
  _ds/                      Phontus Design System: tokens, styles, component bundle
```

To view the prototype, serve the `design/` folder over HTTP and open `Phontus Website.dc.html` — opening it from the filesystem will not work, as it fetches its runtime and tokens relatively.

## Recommended order of work

1. Routes and page shells, with per-page `<title>` and Open Graph tags. This is the biggest gain over the prototype.
2. Global chrome: header (including active state and mobile menu), footer, the green CTA band.
3. Home, then Product with its tabs, then How it works.
4. The solutions overview and four solution pages — they share one template with swapped content.
5. Security, About, Contact, and the three legal pages.
6. Contact form endpoint.
7. Motion: scroll reveal, header condense, scroll progress, marquee. All optional polish; the site must read correctly with none of it running.
