/* @ds-bundle: {"format":4,"namespace":"PhontusDesignSystem_6af7fc","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"SESSION_STATES","sourcePath":"components/feedback/StatusIndicator.jsx"},{"name":"StatusIndicator","sourcePath":"components/feedback/StatusIndicator.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"SidebarNav","sourcePath":"components/navigation/SidebarNav.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"},{"name":"AudioMeter","sourcePath":"components/session/AudioMeter.jsx"},{"name":"LanguagePair","sourcePath":"components/session/LanguagePair.jsx"},{"name":"SessionControl","sourcePath":"components/session/SessionControl.jsx"},{"name":"TranscriptTurn","sourcePath":"components/session/TranscriptTurn.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"9d18d9794891","components/core/Button.jsx":"a9f0b677c000","components/core/Card.jsx":"96dc00ab051c","components/core/Icon.jsx":"2ab6c28449f2","components/core/IconButton.jsx":"0b8d88e80822","components/core/Tag.jsx":"9f4a9db65d44","components/data/DataTable.jsx":"54463ad06e03","components/data/StatCard.jsx":"23ea2833424a","components/feedback/Dialog.jsx":"16206b51a833","components/feedback/StatusIndicator.jsx":"4955871b2e59","components/feedback/Toast.jsx":"b135067571f1","components/feedback/Tooltip.jsx":"df7b85b8d754","components/forms/Checkbox.jsx":"18052d044ddb","components/forms/Input.jsx":"36b6514cd5f9","components/forms/Radio.jsx":"ab9865f8d4da","components/forms/Select.jsx":"28cc65d3a2bb","components/forms/Switch.jsx":"aa155a1471fa","components/forms/Textarea.jsx":"b9bf2ba3b34d","components/navigation/SidebarNav.jsx":"28cc8f08e0e7","components/navigation/Tabs.jsx":"7cf50aacf4d1","components/navigation/TopBar.jsx":"59b9f9970f5c","components/session/AudioMeter.jsx":"8ab3da7e569a","components/session/LanguagePair.jsx":"1905bb746df0","components/session/SessionControl.jsx":"ed454768ec4d","components/session/TranscriptTurn.jsx":"793e221be91b","doc-page.js":"371bab66f42d","ui_kits/admin_console/Login.jsx":"120c8866ccd2","ui_kits/admin_console/Overview.jsx":"135f9b6c7629","ui_kits/admin_console/Records.jsx":"32eb05657b09","ui_kits/admin_console/Shell.jsx":"72796412fa1e","ui_kits/interpreter_console/ActiveCall.jsx":"b80af8cf2a16","ui_kits/interpreter_console/Queue.jsx":"70f21a365368","ui_kits/interpreting_app/LiveSession.jsx":"6715ff21ccb3","ui_kits/interpreting_app/StartScreen.jsx":"4805b93ddd80","ui_kits/marketing_site/Sections.jsx":"87b2e7d53e9c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PhontusDesignSystem_6af7fc = window.PhontusDesignSystem_6af7fc || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const pads = {
  none: 0,
  sm: 'var(--space-4)',
  md: 'var(--space-5)',
  lg: 'var(--space-6)'
};
function Card({
  children,
  title,
  subtitle,
  actions,
  footer,
  padding = 'md',
  elevation = 'sm',
  tone = 'default',
  as: Tag = 'section',
  style,
  ...rest
}) {
  const tones = {
    default: {
      bg: 'var(--surface-card)',
      border: 'var(--border-subtle)'
    },
    sunken: {
      bg: 'var(--surface-sunken)',
      border: 'var(--border-subtle)'
    },
    brand: {
      bg: 'var(--surface-brand-subtle)',
      border: 'var(--green-100)'
    },
    accent: {
      bg: 'var(--surface-accent-subtle)',
      border: 'var(--yellow-200)'
    },
    inverse: {
      bg: 'var(--surface-inverse)',
      border: 'transparent'
    }
  };
  const t = tones[tone] || tones.default;
  const shadow = {
    none: 'none',
    sm: 'var(--shadow-sm)',
    md: 'var(--shadow-md)',
    lg: 'var(--shadow-lg)'
  }[elevation];
  const inverse = tone === 'inverse';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      background: t.bg,
      border: `var(--border-width) solid ${t.border}`,
      borderRadius: 'var(--radius-card)',
      boxShadow: shadow,
      color: inverse ? 'var(--text-inverse)' : 'var(--text-primary)',
      overflow: 'hidden',
      ...style
    }
  }, rest), (title || actions) && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      padding: `var(--space-5) ${pads[padding] || pads.md} var(--space-3)`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-1)'
    }
  }, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--type-h3)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: inverse ? 'rgba(255,255,255,.7)' : 'var(--text-tertiary)'
    }
  }, subtitle)), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      flex: '0 0 auto'
    }
  }, actions)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: title ? `0 ${pads[padding] || pads.md} ${pads[padding] || pads.md}` : pads[padding] || pads.md
    }
  }, children), footer && /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: `var(--space-4) ${pads[padding] || pads.md}`,
      borderTop: `var(--border-width) solid ${inverse ? 'var(--border-inverse)' : 'var(--border-subtle)'}`,
      background: inverse ? 'transparent' : 'var(--neutral-25)'
    }
  }, footer));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Phontus uses Lucide (MIT) as its icon set. The vanilla UMD build is loaded
   once from CDN; this component reads its icon data and renders inline SVG so
   the glyph inherits currentColor and stroke tokens. */
const LUCIDE_SRC = 'https://unpkg.com/lucide@0.469.0/dist/umd/lucide.min.js';
function ensureLucide() {
  if (typeof window === 'undefined') return null;
  if (window.lucide) return window.lucide;
  if (!window.__phontusLucideLoading) {
    window.__phontusLucideLoading = true;
    const s = document.createElement('script');
    s.src = LUCIDE_SRC;
    s.async = true;
    document.head.appendChild(s);
  }
  return null;
}
function toPascal(name) {
  return String(name).replace(/(^|[-_ ])(\w)/g, (_, __, c) => c.toUpperCase());
}
function nodeToElement(node, key) {
  if (!Array.isArray(node)) return null;
  const [tag, attrs, children] = node;
  return React.createElement(tag, {
    key,
    ...(attrs || {})
  }, (children || []).map(nodeToElement));
}
function Icon({
  name,
  size = 20,
  strokeWidth = 1.75,
  color = 'currentColor',
  label,
  style,
  ...rest
}) {
  const [, force] = React.useReducer(n => n + 1, 0);
  React.useEffect(() => {
    if (window.lucide) return;
    ensureLucide();
    const t = setInterval(() => {
      if (window.lucide) {
        clearInterval(t);
        force();
      }
    }, 60);
    const stop = setTimeout(() => clearInterval(t), 4000);
    return () => {
      clearInterval(t);
      clearTimeout(stop);
    };
  }, []);
  const lib = typeof window !== 'undefined' && window.lucide && window.lucide.icons || null;
  const raw = lib ? lib[toPascal(name)] || lib[name] : null;
  const children = raw ? raw[0] === 'svg' ? raw[2] : raw : [];
  return /*#__PURE__*/React.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    role: label ? 'img' : 'presentation',
    "aria-label": label,
    "aria-hidden": label ? undefined : 'true',
    style: {
      display: 'block',
      flex: '0 0 auto',
      ...style
    }
  }, rest), children.map(nodeToElement));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  neutral: {
    bg: 'var(--neutral-100)',
    fg: 'var(--text-secondary)',
    border: 'var(--neutral-200)',
    dot: 'var(--neutral-500)'
  },
  brand: {
    bg: 'var(--green-50)',
    fg: 'var(--green-800)',
    border: 'var(--green-100)',
    dot: 'var(--green-600)'
  },
  live: {
    bg: 'var(--yellow-50)',
    fg: 'var(--yellow-700)',
    border: 'var(--yellow-200)',
    dot: 'var(--yellow-400)'
  },
  human: {
    bg: 'var(--blue-50)',
    fg: 'var(--blue-600)',
    border: 'var(--blue-100)',
    dot: 'var(--blue-500)'
  },
  danger: {
    bg: 'var(--red-50)',
    fg: 'var(--red-600)',
    border: 'var(--red-100)',
    dot: 'var(--red-500)'
  },
  solid: {
    bg: 'var(--green-600)',
    fg: 'var(--white)',
    border: 'transparent',
    dot: 'var(--white)'
  }
};
function Badge({
  children,
  tone = 'neutral',
  dot,
  icon,
  size = 'md',
  style,
  ...rest
}) {
  const t = tones[tone] || tones.neutral;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: sm ? 5 : 6,
      height: sm ? 22 : 26,
      padding: sm ? '0 8px' : '0 10px',
      background: t.bg,
      color: t.fg,
      border: `var(--border-width) solid ${t.border}`,
      borderRadius: 'var(--radius-pill)',
      font: `var(--weight-semibold) ${sm ? 'var(--text-3xs)' : 'var(--text-2xs)'}/1 var(--font-sans)`,
      letterSpacing: 'var(--tracking-wide)',
      whiteSpace: 'nowrap',
      justifySelf: 'start',
      alignSelf: 'center',
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: t.dot,
      flex: '0 0 auto'
    }
  }), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: sm ? 12 : 14
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: {
    height: 36,
    padding: '0 12px',
    font: 'var(--text-sm)',
    gap: 6,
    icon: 16
  },
  md: {
    height: 44,
    padding: '0 18px',
    font: 'var(--text-sm)',
    gap: 8,
    icon: 18
  },
  lg: {
    height: 52,
    padding: '0 24px',
    font: 'var(--text-base)',
    gap: 10,
    icon: 20
  },
  xl: {
    height: 64,
    padding: '0 32px',
    font: 'var(--text-md)',
    gap: 12,
    icon: 24
  }
};
const variants = {
  primary: {
    bg: 'var(--action-primary)',
    hover: 'var(--action-primary-hover)',
    active: 'var(--action-primary-active)',
    fg: 'var(--text-on-brand)',
    border: 'transparent',
    shadow: 'var(--shadow-xs)'
  },
  secondary: {
    bg: 'var(--action-secondary)',
    hover: 'var(--action-secondary-hover)',
    active: 'var(--surface-active)',
    fg: 'var(--text-primary)',
    border: 'var(--border-default)',
    shadow: 'var(--shadow-xs)'
  },
  ghost: {
    bg: 'transparent',
    hover: 'var(--surface-hover)',
    active: 'var(--surface-active)',
    fg: 'var(--text-secondary)',
    border: 'transparent',
    shadow: 'none'
  },
  accent: {
    bg: 'var(--yellow-300)',
    hover: 'var(--yellow-400)',
    active: 'var(--yellow-500)',
    fg: 'var(--text-on-accent)',
    border: 'transparent',
    shadow: 'var(--shadow-xs)'
  },
  danger: {
    bg: 'var(--action-danger)',
    hover: 'var(--action-danger-hover)',
    active: 'var(--red-700)',
    fg: 'var(--white)',
    border: 'transparent',
    shadow: 'var(--shadow-xs)'
  },
  inverse: {
    bg: 'rgba(255,255,255,.12)',
    hover: 'rgba(255,255,255,.2)',
    active: 'rgba(255,255,255,.28)',
    fg: 'var(--white)',
    border: 'var(--border-inverse)',
    shadow: 'none'
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  fullWidth,
  disabled,
  loading,
  type = 'button',
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  const off = disabled || loading;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: off,
    onClick: off ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      height: s.height,
      padding: s.padding,
      font: `var(--weight-semibold) ${s.font}/1 var(--font-sans)`,
      letterSpacing: 'var(--tracking-tight)',
      color: off ? 'var(--text-muted)' : v.fg,
      background: off ? 'var(--surface-disabled)' : press ? v.active : hover ? v.hover : v.bg,
      border: `var(--border-width) solid ${off ? 'var(--border-subtle)' : v.border}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: off ? 'none' : v.shadow,
      cursor: off ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), loading ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "loader-circle",
    size: s.icon,
    style: {
      animation: 'phontus-spin 1s linear infinite'
    }
  }) : iconLeft ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }) : null, children, iconRight ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const boxes = {
  sm: 36,
  md: 44,
  lg: 52,
  xl: 64
};
const glyphs = {
  sm: 18,
  md: 20,
  lg: 24,
  xl: 28
};
function IconButton({
  icon,
  label,
  variant = 'ghost',
  size = 'md',
  shape = 'rounded',
  disabled,
  active,
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const box = boxes[size] || boxes.md;
  const tone = {
    ghost: {
      bg: 'transparent',
      fg: 'var(--text-secondary)',
      border: 'transparent'
    },
    secondary: {
      bg: 'var(--white)',
      fg: 'var(--text-primary)',
      border: 'var(--border-default)'
    },
    primary: {
      bg: 'var(--action-primary)',
      fg: 'var(--text-on-brand)',
      border: 'transparent'
    },
    danger: {
      bg: 'var(--red-50)',
      fg: 'var(--text-danger)',
      border: 'var(--red-100)'
    },
    inverse: {
      bg: 'rgba(255,255,255,.12)',
      fg: 'var(--white)',
      border: 'var(--border-inverse)'
    }
  }[variant] || {
    bg: 'transparent',
    fg: 'var(--text-secondary)',
    border: 'transparent'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    "aria-pressed": active,
    title: label,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: box,
      height: box,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: disabled ? 'var(--text-muted)' : active ? 'var(--text-brand)' : tone.fg,
      background: disabled ? 'var(--surface-disabled)' : active ? 'var(--surface-brand-subtle)' : hover ? variant === 'primary' ? 'var(--action-primary-hover)' : variant === 'inverse' ? 'rgba(255,255,255,.2)' : 'var(--surface-hover)' : tone.bg,
      border: `var(--border-width) solid ${tone.border}`,
      borderRadius: shape === 'circle' ? 'var(--radius-pill)' : 'var(--radius-control)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: glyphs[size] || glyphs.md
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  onRemove,
  icon,
  selected,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 30,
      padding: onRemove ? '0 6px 0 10px' : '0 10px',
      background: selected ? 'var(--green-50)' : 'var(--white)',
      color: selected ? 'var(--green-800)' : 'var(--text-secondary)',
      border: `var(--border-width) solid ${selected ? 'var(--green-200)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-sm)',
      font: 'var(--weight-medium) var(--text-xs)/1 var(--font-sans)',
      justifySelf: 'start',
      alignSelf: 'center',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  }), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onRemove,
    "aria-label": "Remove",
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 18,
      height: 18,
      border: 0,
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      borderRadius: 'var(--radius-xs)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function DataTable({
  columns = [],
  rows = [],
  onRowClick,
  empty = 'Nothing here yet.',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(-1);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      border: 'var(--border-width) solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '10px var(--space-4)',
      background: 'var(--neutral-25)',
      borderBottom: 'var(--border-width) solid var(--border-subtle)',
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap',
      width: c.width
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.length === 0 && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: columns.length,
    style: {
      padding: 'var(--space-8)',
      textAlign: 'center',
      font: 'var(--type-body-sm)',
      color: 'var(--text-muted)'
    }
  }, empty)), rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: r.id || i,
    onClick: onRowClick ? () => onRowClick(r) : undefined,
    onMouseEnter: () => setHover(i),
    onMouseLeave: () => setHover(-1),
    style: {
      background: hover === i && onRowClick ? 'var(--neutral-25)' : 'transparent',
      cursor: onRowClick ? 'pointer' : 'default',
      transition: 'background-color var(--duration-fast) var(--ease-standard)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '14px var(--space-4)',
      borderBottom: i === rows.length - 1 ? 0 : 'var(--border-width) solid var(--border-subtle)',
      font: c.mono ? 'var(--type-mono)' : 'var(--type-body-sm)',
      color: c.muted ? 'var(--text-tertiary)' : 'var(--text-primary)',
      fontVariantNumeric: c.mono ? 'tabular-nums' : undefined,
      verticalAlign: 'middle'
    }
  }, c.render ? c.render(r) : r[c.key])))))), onRowClick && rows.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
      gap: 6,
      padding: 'var(--space-3) var(--space-4)',
      borderTop: 'var(--border-width) solid var(--border-subtle)',
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, rows.length, " rows ", /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 14
  })));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatCard({
  label,
  value,
  unit,
  delta,
  deltaTone = 'neutral',
  caption,
  icon,
  style,
  ...rest
}) {
  const tone = {
    up: 'var(--green-700)',
    down: 'var(--red-600)',
    neutral: 'var(--text-tertiary)'
  }[deltaTone];
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      padding: 'var(--space-5)',
      background: 'var(--surface-card)',
      border: 'var(--border-width) solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-xs)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)'
    }
  }, label)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) var(--text-2xl)/1 var(--font-display)',
      letterSpacing: 'var(--tracking-tighter)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, unit), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      font: 'var(--weight-semibold) var(--text-xs)/1 var(--font-sans)',
      color: tone
    }
  }, deltaTone !== 'neutral' && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: deltaTone === 'up' ? 'trending-up' : 'trending-down',
    size: 14
  }), delta)), caption && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, caption));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = true,
  title,
  description,
  children,
  footer,
  onClose,
  width = 480,
  tone = 'default',
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 60,
      display: 'grid',
      placeItems: 'center',
      padding: 'var(--space-6)',
      background: 'var(--scrim)',
      backdropFilter: 'var(--blur-overlay)'
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    style: {
      width,
      maxWidth: '100%',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-surface)',
      boxShadow: 'var(--shadow-xl)',
      overflow: 'hidden',
      animation: 'phontus-fade-up var(--duration-normal) var(--ease-out)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-6) var(--space-6) var(--space-4)',
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'flex-start'
    }
  }, tone !== 'default' && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      flex: '0 0 auto',
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-pill)',
      background: tone === 'danger' ? 'var(--red-50)' : 'var(--yellow-50)',
      color: tone === 'danger' ? 'var(--red-500)' : 'var(--yellow-600)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "triangle-alert",
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--type-h2)',
      fontSize: 'var(--text-lg)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, description)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Close",
    style: {
      marginLeft: 'auto',
      border: 0,
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      padding: 4
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 18
  }))), children && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 var(--space-6) var(--space-5)'
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 'var(--space-3)',
      padding: 'var(--space-4) var(--space-6)',
      borderTop: 'var(--border-width) solid var(--border-subtle)',
      background: 'var(--neutral-25)'
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusIndicator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The single vocabulary for every live session state. Colour + label + motion
   always travel together — colour alone is never the signal. */
const SESSION_STATES = {
  idle: {
    label: 'Ready',
    color: 'var(--neutral-500)',
    surface: 'var(--neutral-100)',
    text: 'var(--text-secondary)',
    icon: 'circle',
    pulse: false
  },
  connecting: {
    label: 'Connecting',
    color: 'var(--state-connecting)',
    surface: 'var(--neutral-100)',
    text: 'var(--text-secondary)',
    icon: 'loader-circle',
    pulse: true
  },
  listening: {
    label: 'Listening',
    color: 'var(--state-listening)',
    surface: 'var(--state-listening-surface)',
    text: 'var(--green-800)',
    icon: 'mic',
    pulse: true
  },
  interpreting: {
    label: 'Interpreting',
    color: 'var(--state-live)',
    surface: 'var(--state-live-surface)',
    text: 'var(--state-live-text)',
    icon: 'audio-lines',
    pulse: true
  },
  speaking: {
    label: 'Speaking',
    color: 'var(--state-speaking)',
    surface: 'var(--green-50)',
    text: 'var(--green-800)',
    icon: 'volume-2',
    pulse: true
  },
  reconnecting: {
    label: 'Reconnecting',
    color: 'var(--state-reconnecting)',
    surface: 'var(--yellow-50)',
    text: 'var(--yellow-700)',
    icon: 'wifi',
    pulse: true
  },
  human: {
    label: 'Human interpreter',
    color: 'var(--state-human)',
    surface: 'var(--state-human-surface)',
    text: 'var(--blue-600)',
    icon: 'user-round',
    pulse: false
  },
  muted: {
    label: 'Muted',
    color: 'var(--state-muted)',
    surface: 'var(--neutral-100)',
    text: 'var(--text-secondary)',
    icon: 'mic-off',
    pulse: false
  },
  error: {
    label: 'Connection lost',
    color: 'var(--state-error)',
    surface: 'var(--red-50)',
    text: 'var(--red-600)',
    icon: 'triangle-alert',
    pulse: false
  },
  ended: {
    label: 'Session ended',
    color: 'var(--state-ended)',
    surface: 'var(--neutral-100)',
    text: 'var(--text-tertiary)',
    icon: 'check',
    pulse: false
  }
};
function StatusIndicator({
  state = 'idle',
  label,
  size = 'md',
  variant = 'pill',
  style,
  ...rest
}) {
  const s = SESSION_STATES[state] || SESSION_STATES.idle;
  const text = label || s.label;
  const lg = size === 'lg';
  const dotSize = lg ? 14 : 9;
  const dot = /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      width: dotSize,
      height: dotSize,
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 999,
      background: s.color,
      animation: s.pulse ? 'phontus-pulse var(--duration-pulse) var(--ease-in-out) infinite' : 'none'
    }
  }));
  if (variant === 'dot') return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      justifySelf: 'start',
      alignSelf: 'center',
      ...style
    }
  }, rest), dot, /*#__PURE__*/React.createElement("span", {
    style: {
      font: lg ? 'var(--type-body)' : 'var(--type-body-sm)',
      color: 'var(--text-secondary)'
    }
  }, text));
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: lg ? 10 : 7,
      height: lg ? 44 : 30,
      padding: lg ? '0 18px' : '0 12px',
      background: s.surface,
      color: s.text,
      borderRadius: 'var(--radius-pill)',
      font: `var(--weight-semibold) ${lg ? 'var(--text-base)' : 'var(--text-xs)'}/1 var(--font-sans)`,
      letterSpacing: 'var(--tracking-wide)',
      justifySelf: 'start',
      alignSelf: 'center',
      ...style
    }
  }, rest), variant === 'icon' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: s.icon,
    size: lg ? 22 : 16
  }) : dot, text);
}
Object.assign(__ds_scope, { SESSION_STATES, StatusIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusIndicator.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  info: {
    icon: 'info',
    color: 'var(--green-700)'
  },
  success: {
    icon: 'check-circle',
    color: 'var(--green-600)'
  },
  warning: {
    icon: 'triangle-alert',
    color: 'var(--yellow-500)'
  },
  error: {
    icon: 'circle-x',
    color: 'var(--red-500)'
  }
};
function Toast({
  title,
  description,
  tone = 'info',
  action,
  onDismiss,
  style,
  ...rest
}) {
  const t = tones[tone] || tones.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      width: 380,
      maxWidth: '100%',
      padding: 'var(--space-4)',
      background: 'var(--white)',
      border: 'var(--border-width) solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-lg)',
      animation: 'phontus-fade-up var(--duration-normal) var(--ease-out)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 20,
    color: t.color,
    style: {
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      gap: 'var(--space-1)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-primary)'
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, description), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-2)'
    }
  }, action)), onDismiss && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onDismiss,
    "aria-label": "Dismiss",
    style: {
      border: 0,
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      padding: 2,
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 16
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  children,
  content,
  side = 'top',
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translate(-50%,-8px)'
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translate(-50%,8px)'
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translate(-8px,-50%)'
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translate(8px,-50%)'
    }
  }[side];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, rest), children, open && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      ...pos,
      zIndex: 40,
      padding: '6px 10px',
      maxWidth: 240,
      background: 'var(--neutral-900)',
      color: 'var(--white)',
      font: 'var(--weight-medium) var(--text-2xs)/1.35 var(--font-sans)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-md)',
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      animation: 'phontus-fade-up var(--duration-fast) var(--ease-out)'
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  description,
  checked,
  indeterminate,
  disabled,
  onChange,
  id,
  style,
  ...rest
}) {
  const uid = id || React.useId();
  const on = checked || indeterminate;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: description ? 'flex-start' : 'center',
      minHeight: 'var(--touch-min)',
      padding: '2px 0',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    type: "checkbox",
    checked: !!checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 20,
      height: 20,
      flex: '0 0 auto',
      display: 'grid',
      placeItems: 'center',
      marginTop: description ? 2 : 0,
      background: on ? 'var(--action-primary)' : 'var(--white)',
      border: `var(--border-width-strong) solid ${on ? 'var(--action-primary)' : 'var(--border-strong)'}`,
      borderRadius: 'var(--radius-xs)',
      color: 'var(--white)',
      transition: 'var(--transition-control)'
    }
  }, indeterminate ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "minus",
    size: 14
  }) : checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    strokeWidth: 2.5
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const heights = {
  sm: 36,
  md: 44,
  lg: 52
};
function Input({
  label,
  hint,
  error,
  iconLeft,
  suffix,
  size = 'md',
  id,
  required,
  disabled,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  const h = heights[size] || heights.md;
  const borderColor = error ? 'var(--red-500)' : focus ? 'var(--border-brand)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-secondary)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-danger)'
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: h,
      padding: '0 12px',
      background: disabled ? 'var(--surface-disabled)' : 'var(--white)',
      border: `var(--border-width) solid ${borderColor}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-xs)',
      color: 'var(--text-muted)',
      transition: 'var(--transition-control)'
    }
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 18
  }), /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    disabled: disabled,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      font: size === 'lg' ? 'var(--type-body-lg)' : 'var(--type-body)',
      color: 'var(--text-primary)',
      ...style
    }
  }, rest)), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-muted)'
    }
  }, suffix)), (error || hint) && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: error ? 'var(--text-danger)' : 'var(--text-tertiary)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  description,
  checked,
  disabled,
  name,
  value,
  onChange,
  id,
  style,
  ...rest
}) {
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: description ? 'flex-start' : 'center',
      minHeight: 'var(--touch-min)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    type: "radio",
    name: name,
    value: value,
    checked: !!checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 20,
      height: 20,
      flex: '0 0 auto',
      display: 'grid',
      placeItems: 'center',
      marginTop: description ? 2 : 0,
      background: 'var(--white)',
      border: `var(--border-width-strong) solid ${checked ? 'var(--action-primary)' : 'var(--border-strong)'}`,
      borderRadius: 'var(--radius-pill)',
      transition: 'var(--transition-control)'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 999,
      background: 'var(--action-primary)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, description)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const heights = {
  sm: 36,
  md: 44,
  lg: 52
};
function Select({
  label,
  hint,
  error,
  options = [],
  size = 'md',
  id,
  disabled,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: uid,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      width: '100%',
      height: heights[size] || heights.md,
      padding: '0 38px 0 12px',
      font: 'var(--type-body)',
      color: 'var(--text-primary)',
      background: disabled ? 'var(--surface-disabled)' : 'var(--white)',
      border: `var(--border-width) solid ${error ? 'var(--red-500)' : focus ? 'var(--border-brand)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-xs)',
      outline: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'var(--transition-control)',
      ...style
    }
  }, rest), options.map(o => {
    const opt = typeof o === 'string' ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18,
    style: {
      position: 'absolute',
      right: 12,
      color: 'var(--text-muted)',
      pointerEvents: 'none'
    }
  })), (error || hint) && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: error ? 'var(--text-danger)' : 'var(--text-tertiary)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  label,
  description,
  checked,
  disabled,
  onChange,
  id,
  style,
  ...rest
}) {
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'center',
      justifyContent: 'space-between',
      minHeight: 'var(--touch-min)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, description)), /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    type: "checkbox",
    role: "switch",
    checked: !!checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 44,
      height: 26,
      flex: '0 0 auto',
      padding: 3,
      display: 'flex',
      alignItems: 'center',
      background: checked ? 'var(--action-primary)' : 'var(--neutral-300)',
      borderRadius: 'var(--radius-pill)',
      transition: 'background-color var(--duration-fast) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: 999,
      background: 'var(--white)',
      boxShadow: 'var(--shadow-xs)',
      transform: checked ? 'translateX(18px)' : 'none',
      transition: 'transform var(--duration-fast) var(--ease-standard)'
    }
  })));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  label,
  hint,
  error,
  rows = 4,
  id,
  disabled,
  style,
  wrapperStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...wrapperStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: uid,
    rows: rows,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      padding: '12px',
      resize: 'vertical',
      font: 'var(--type-body)',
      color: 'var(--text-primary)',
      background: disabled ? 'var(--surface-disabled)' : 'var(--white)',
      border: `var(--border-width) solid ${error ? 'var(--red-500)' : focus ? 'var(--border-brand)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-control)',
      boxShadow: focus ? 'var(--shadow-focus)' : 'var(--shadow-xs)',
      outline: 'none',
      transition: 'var(--transition-control)',
      ...style
    }
  }, rest)), (error || hint) && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: error ? 'var(--text-danger)' : 'var(--text-tertiary)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SidebarNav.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SidebarNav({
  items = [],
  value,
  onChange,
  footer,
  logoSrc,
  orgName,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      width: 'var(--sidebar-width)',
      flex: '0 0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      height: '100%',
      padding: 'var(--space-5) var(--space-4)',
      background: 'var(--white)',
      borderRight: 'var(--border-width) solid var(--border-subtle)',
      ...style
    }
  }, rest), (logoSrc || orgName) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      padding: '0 var(--space-2)'
    }
  }, logoSrc && /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "Phontus",
    style: {
      height: 22,
      display: 'block'
    }
  }), orgName && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase'
    }
  }, orgName)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, groupItems(items).map((group, gi) => /*#__PURE__*/React.createElement("div", {
    key: gi,
    style: {
      display: 'grid',
      gap: 2
    }
  }, group.title && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)',
      padding: '0 var(--space-2) var(--space-2)'
    }
  }, group.title), group.items.map(it => {
    const on = it.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      onClick: () => onChange && onChange(it.value),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        width: '100%',
        minHeight: 40,
        padding: '0 var(--space-3)',
        border: 0,
        cursor: 'pointer',
        textAlign: 'left',
        background: on ? 'var(--surface-brand-subtle)' : 'transparent',
        color: on ? 'var(--green-800)' : 'var(--text-secondary)',
        borderRadius: 'var(--radius-sm)',
        font: `var(--weight-${on ? 'semibold' : 'medium'}) var(--text-sm)/1 var(--font-sans)`,
        transition: 'var(--transition-control)'
      }
    }, it.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 18
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, it.label), it.badge != null && /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-mono)',
        color: on ? 'var(--green-700)' : 'var(--text-muted)'
      }
    }, it.badge));
  })))), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, footer));
}
function groupItems(items) {
  const out = [];
  let current = {
    title: null,
    items: []
  };
  items.forEach(it => {
    if (it.group) {
      if (current.items.length) out.push(current);
      current = {
        title: it.group,
        items: []
      };
    } else current.items.push(it);
  });
  if (current.items.length) out.push(current);
  return out;
}
Object.assign(__ds_scope, { SidebarNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SidebarNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  value,
  onChange,
  variant = 'underline',
  style,
  ...rest
}) {
  const active = value ?? (items[0] && (items[0].value || items[0]));
  const norm = items.map(i => typeof i === 'string' ? {
    value: i,
    label: i
  } : i);
  if (variant === 'segmented') {
    return /*#__PURE__*/React.createElement("div", _extends({
      role: "tablist",
      style: {
        display: 'inline-flex',
        gap: 2,
        padding: 3,
        background: 'var(--surface-sunken)',
        border: 'var(--border-width) solid var(--border-subtle)',
        borderRadius: 'var(--radius-md)',
        ...style
      }
    }, rest), norm.map(t => {
      const on = t.value === active;
      return /*#__PURE__*/React.createElement("button", {
        key: t.value,
        role: "tab",
        "aria-selected": on,
        onClick: () => onChange && onChange(t.value),
        style: {
          display: 'inline-flex',
          alignItems: 'center',
          gap: 7,
          height: 34,
          padding: '0 14px',
          border: 0,
          borderRadius: 'var(--radius-sm)',
          cursor: 'pointer',
          background: on ? 'var(--white)' : 'transparent',
          color: on ? 'var(--text-primary)' : 'var(--text-tertiary)',
          boxShadow: on ? 'var(--shadow-xs)' : 'none',
          font: 'var(--weight-semibold) var(--text-sm)/1 var(--font-sans)',
          transition: 'var(--transition-control)'
        }
      }, t.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
        name: t.icon,
        size: 16
      }), t.label);
    }));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      borderBottom: 'var(--border-width) solid var(--border-subtle)',
      ...style
    }
  }, rest), norm.map(t => {
    const on = t.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => onChange && onChange(t.value),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        height: 44,
        padding: '0 2px',
        border: 0,
        background: 'transparent',
        cursor: 'pointer',
        color: on ? 'var(--text-primary)' : 'var(--text-tertiary)',
        boxShadow: on ? 'inset 0 -2px 0 0 var(--action-primary)' : 'none',
        font: `var(--weight-${on ? 'semibold' : 'medium'}) var(--text-sm)/1 var(--font-sans)`,
        transition: 'var(--transition-control)'
      }
    }, t.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: t.icon,
      size: 16
    }), t.label, t.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-mono)',
        color: 'var(--text-muted)'
      }
    }, t.count));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TopBar({
  title,
  subtitle,
  breadcrumbs = [],
  actions,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      minHeight: 'var(--topbar-height)',
      padding: '0 var(--space-6)',
      background: 'var(--white)',
      borderBottom: 'var(--border-width) solid var(--border-subtle)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 2,
      minWidth: 0
    }
  }, breadcrumbs.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, breadcrumbs.map((b, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 12
  }), /*#__PURE__*/React.createElement("span", null, b)))), title && /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--weight-bold) var(--text-lg)/1.2 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, subtitle)), children, actions && /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, actions));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// components/session/AudioMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Ambient proof that audio is flowing. Bars are decorative-but-informative:
   they animate only while `active`. */
function AudioMeter({
  active = true,
  bars = 9,
  tone = 'brand',
  height = 32,
  style,
  ...rest
}) {
  const color = tone === 'accent' ? 'var(--yellow-300)' : tone === 'muted' ? 'var(--neutral-300)' : 'var(--action-primary)';
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "presentation",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      height,
      ...style
    }
  }, rest), Array.from({
    length: bars
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 4,
      height: '100%',
      borderRadius: 999,
      background: color,
      transformOrigin: 'center',
      transform: active ? undefined : 'scaleY(.22)',
      opacity: active ? 1 : 0.5,
      animation: active ? `phontus-bar ${900 + i % 4 * 220}ms var(--ease-in-out) ${i * 70}ms infinite` : 'none'
    }
  })));
}
Object.assign(__ds_scope, { AudioMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/session/AudioMeter.jsx", error: String((e && e.message) || e) }); }

// components/session/LanguagePair.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Languages are named in words — never represented by a flag. */
function LanguagePair({
  from,
  to,
  fromLabel = 'Speaker',
  toLabel = 'Listener',
  size = 'md',
  onSwap,
  active,
  style,
  ...rest
}) {
  const lg = size === 'lg';
  const side = (name, role, live) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: live ? 'var(--green-700)' : 'var(--text-muted)'
    }
  }, role), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-semibold) ${lg ? 'var(--text-xl)' : 'var(--text-base)'}/1.2 var(--font-display)`,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--text-primary)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, name));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: lg ? 'var(--space-6)' : 'var(--space-4)',
      padding: lg ? 'var(--space-5) var(--space-6)' : 'var(--space-3) var(--space-4)',
      background: 'var(--white)',
      border: `var(--border-width) solid ${active ? 'var(--green-200)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-xs)',
      ...style
    }
  }, rest), side(from, fromLabel, active), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSwap,
    "aria-label": "Swap languages",
    disabled: !onSwap,
    style: {
      width: lg ? 44 : 36,
      height: lg ? 44 : 36,
      flex: '0 0 auto',
      display: 'grid',
      placeItems: 'center',
      border: 'var(--border-width) solid var(--border-subtle)',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--neutral-50)',
      color: 'var(--text-secondary)',
      cursor: onSwap ? 'pointer' : 'default'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right-left",
    size: lg ? 20 : 16
  })), side(to, toLabel));
}
Object.assign(__ds_scope, { LanguagePair });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/session/LanguagePair.jsx", error: String((e && e.message) || e) }); }

// components/session/SessionControl.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The largest, most obvious control in the product. One per screen. */
const looks = {
  start: {
    bg: 'var(--action-primary)',
    fg: 'var(--white)',
    icon: 'play',
    label: 'Start session'
  },
  live: {
    bg: 'var(--yellow-300)',
    fg: 'var(--neutral-900)',
    icon: 'audio-lines',
    label: 'Interpreting'
  },
  hold: {
    bg: 'var(--white)',
    fg: 'var(--text-primary)',
    icon: 'pause',
    label: 'Hold'
  },
  end: {
    bg: 'var(--action-danger)',
    fg: 'var(--white)',
    icon: 'phone-off',
    label: 'End session'
  },
  talk: {
    bg: 'var(--green-900)',
    fg: 'var(--white)',
    icon: 'mic',
    label: 'Hold to speak'
  }
};
function SessionControl({
  action = 'start',
  label,
  caption,
  state,
  size = 176,
  disabled,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const look = looks[action] || looks.start;
  const st = state ? __ds_scope.SESSION_STATES[state] : null;
  const ring = action === 'live' ? 'var(--glow-live)' : action === 'talk' ? 'var(--glow-listening)' : 'none';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      justifyItems: 'center',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    "aria-label": label || look.label,
    style: {
      width: size,
      height: size,
      display: 'grid',
      placeItems: 'center',
      gap: 'var(--space-2)',
      background: disabled ? 'var(--surface-disabled)' : look.bg,
      color: disabled ? 'var(--text-muted)' : look.fg,
      border: action === 'hold' ? 'var(--border-width-strong) solid var(--border-default)' : 0,
      borderRadius: 'var(--radius-pill)',
      boxShadow: press ? 'var(--shadow-sm)' : hover ? `var(--shadow-lg), ${ring}` : `var(--shadow-md), ${ring}`,
      transform: press ? 'scale(.975)' : 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'transform var(--duration-fast) var(--ease-standard), box-shadow var(--duration-normal) var(--ease-standard), background-color var(--duration-normal) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: look.icon,
    size: Math.round(size * 0.26),
    strokeWidth: 1.6
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--weight-bold) ${size > 140 ? 'var(--text-lg)' : 'var(--text-sm)'}/1.15 var(--font-display)`,
      letterSpacing: 'var(--tracking-tight)',
      maxWidth: size - 32,
      textAlign: 'center'
    }
  }, label || look.label)), (caption || st) && /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-tertiary)',
      textAlign: 'center'
    }
  }, caption || st.label));
}
Object.assign(__ds_scope, { SessionControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/session/SessionControl.jsx", error: String((e && e.message) || e) }); }

// components/session/TranscriptTurn.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TranscriptTurn({
  speaker,
  language,
  original,
  translation,
  time,
  source = 'ai',
  pending,
  size = 'md',
  style,
  ...rest
}) {
  const lg = size === 'lg';
  return /*#__PURE__*/React.createElement("article", _extends({
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      padding: lg ? 'var(--space-5) 0' : 'var(--space-4) 0',
      borderTop: 'var(--border-width) solid var(--border-subtle)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-primary)'
    }
  }, speaker), language && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, language), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      font: 'var(--type-caption)',
      color: source === 'human' ? 'var(--blue-600)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: source === 'human' ? 'user-round' : 'sparkles',
    size: 12
  }), source === 'human' ? 'Human' : 'AI'), time && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      font: 'var(--type-mono)',
      color: 'var(--text-muted)'
    }
  }, time)), /*#__PURE__*/React.createElement("p", {
    style: {
      font: lg ? `var(--weight-regular) var(--text-session)/1.3 var(--font-sans)` : 'var(--type-body-lg)',
      color: 'var(--text-primary)',
      textWrap: 'pretty'
    }
  }, original), translation && /*#__PURE__*/React.createElement("p", {
    style: {
      font: lg ? `var(--weight-regular) var(--text-lg)/1.4 var(--font-sans)` : 'var(--type-body)',
      color: pending ? 'var(--text-muted)' : 'var(--text-secondary)',
      paddingLeft: 'var(--space-4)',
      borderLeft: `2px solid ${pending ? 'var(--neutral-300)' : 'var(--green-200)'}`,
      textWrap: 'pretty'
    }
  }, translation));
}
Object.assign(__ds_scope, { TranscriptTurn });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/session/TranscriptTurn.jsx", error: String((e && e.message) || e) }); }

// doc-page.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <doc-page> — paged-document shell for printable HTML.
 *
 * FIRST, decide how the document paginates — up front, before building:
 *
 * - FLOWING document (the default): write the whole document as one
 *   normal HTML flow inside <doc-page>; the browser's print engine
 *   splits it onto pages at export. Use for long-form documents with a
 *   single text flow: reports, memos, letters, essays.
 * - EXPLICIT pagination: a fixed set of pre-paginated pages, one
 *   <section class="page"> child per page. Use when the user asks for a
 *   specific page count, or the design implies one: a one-page resume, a
 *   two-sided flier, a poster, a certificate, a brochure — any richly
 *   laid-out document without a single text flow.
 * - If in doubt, ask the user as part of the build.
 *
 * PAGE SIZING — paper differs by country (letter vs A4), so the printed
 * sheet is not one fixed truth:
 * - FLOWING documents pin NO paper size: the print engine paginates
 *   onto the user's real paper, and the content reflows to it.
 * - EXPLICITLY PAGINATED documents print each page at a FIXED page box
 *   with overflow hidden — letter by default, size="a4" for a clearly
 *   metric user, the user's chosen paper when they export. Design each
 *   page to FILL that box, fitting letter and A4 alike without overlap.
 * - width/height pin an explicit fixed size, ONLY when the user gives
 *   one.
 * Never write your own @page rule or hard-code paper dimensions in the
 * content.
 *
 * Sizing modes (attributes):
 *   (none)                      — portrait: flowing docs use the user's
 *           paper; explicitly paginated pages use the named size box
 *           (letter unless size="a4")
 *   orientation="landscape"     — the same, landscape
 *   width / height              — explicit fixed size, ONLY when the user
 *           gives one (e.g. width="22in" height="30in" for a 22×30
 *           poster): the page IS the design's size, printed at true
 *           dimensions (or scaled onto the user's paper at print time).
 *           Any absolute CSS length: px/in/mm/cm/pt/pc.
 * The component announces the chosen mode to the host app at runtime (a
 * meta tag it injects), so the print path can inject the user's true
 * paper size.
 *
 * On screen the document renders on a desk background: a flowing
 * document as one tall scrolling sheet (Google Docs' pageless view);
 * explicitly paginated documents as one card per page.
 *
 * EXPLICIT pagination usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page>
 *     <section class="page" id="p1">…one page's design…</section>
 *     <section class="page" id="p2">…</section>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * How the page box works, concretely: each .page prints as ONE full-bleed
 * sheet at a FIXED physical size — letter by default (set size="a4" for
 * a clearly metric user), the user's chosen paper when they export —
 * with overflow hidden. Nothing scrolls and nothing reflows onto a next
 * sheet: content that misses the box is CLIPPED. Design each page to
 * FILL that page box, and to fit it — letter and A4 alike — without
 * overlap. Each page is a size container; don't size anything in
 * viewport units (they track the window, not the page), and never set
 * width or height on the .page section itself (the component sizes the
 * page box; an authored height like 100% is meaningless at print and is
 * overridden). The component owns the page box, the screen card chrome,
 * and the page breaks (never add your own break-before/after). Don't mix
 * .page sections with flowing content or header/footer slots in the same
 * document.
 *
 * FLOWING usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page margin="0.75in">
 *     <h1>Title</h1>
 *     <p>…body…</p>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * There is no manual page-splitting — the browser's print engine
 * paginates at export. Standard break-hygiene rules (`break-inside:
 * avoid` on figures, code blocks, images and table rows; `orphans/
 * widows: 3`) are applied so paragraphs and groups split cleanly. On
 * screen and at print, headings default to `text-wrap: balance` and
 * body text to `text-wrap: pretty`; the defaults have zero specificity,
 * so any text-wrap you declare wins.
 *
 * Other attributes:
 *   size    — letter | a4 | legal (default letter). Flowing documents:
 *           preview proportion only — it does NOT pin their printed
 *           paper (the print dialog's paper governs); leave it alone
 *           there. Explicitly paginated documents: it sets the page box
 *           the cards and the pinned @page share (the export dialog's
 *           choice overrides both at print) — set size="a4" for a
 *           clearly metric user. Scaled-fit: names the sheet the fit is
 *           computed against, same a4-for-metric-users advice.
 *   content-width / content-height — the design's own fixed dimensions
 *           (CSS lengths), for scaling a fixed-size design ONTO the
 *           named sheet: content lays out at exactly this size, and the
 *           component scales it to fit that sheet's printable area
 *           (centered horizontally, top-aligned; the export dialog
 *           re-fits to the user's actual paper choice where available).
 *           Both must be set; they do not change the page box. For pages
 *           WITHOUT running header/footer slots.
 *   margin  — printable inset on every page of a FLOWING document
 *           (default 0.75in); margin="0" makes pages full-bleed.
 *           Explicitly paginated pages are always full-bleed.
 *
 * Running header/footer (flowing documents only): give an element
 * `slot="header"` or `slot="footer"` and it repeats on every printed
 * page via `position: fixed`. To keep body text from sliding under it,
 * the component prints inside a single-cell table whose <thead>/<tfoot>
 * are spacers sized to the header/footer height — browsers repeat
 * thead/tfoot on every page, so each sheet's content starts below the
 * header and ends above the footer. On screen the header/footer render
 * once at the top/bottom of the sheet.
 *
 * At print the component injects `@page { margin: 0 }` (which leaves
 * Chrome no margin box to draw its date/URL/page-count header in) and
 * moves the visual margin onto the sheet's own padding. It also marks
 * the document as owning its print CSS (a
 * `meta[name="omelette-owns-print"]` it injects at runtime), so the
 * PDF export never injects page-geometry CSS of its own on top.
 *
 * Print best practices for the content you author:
 * - Multi-column text: use CSS columns (`column-count` +
 *   `column-gap`), never side-by-side flex/grid columns — only real
 *   CSS columns flow and break across pages. `column-span: all` lets
 *   a heading span the columns; `hyphens: auto` (needs `lang` on
 *   the html element) keeps narrow columns readable.
 * - Page breaks in flowing documents: `break-before: page` on an
 *   element that must start a new page (a chapter, an appendix). Add
 *   your own kept-together blocks (callouts, stat tiles, cards) to a
 *   `break-inside: avoid` rule, and keep each one shorter than a page.
 * - Extend `orphans: 3; widows: 3` to any custom text blocks you add
 *   (p and li are covered by default).
 * - Give long tables a <thead> — browsers repeat it on every printed
 *   page.
 * - No `position: fixed`/`sticky` and no viewport units in content:
 *   fixed elements stamp every printed page (running headers/footers go
 *   in the component's slots) and `100vh` mis-sizes at print.
 *
 * Author content as static HTML so the user can click-to-edit any text
 * directly. Do not set width/padding/background on the document body —
 * the component owns the sheet box.
 */
/* END USAGE */

(() => {
  const PAPER = {
    letter: ['8.5in', '11in'],
    a4: ['210mm', '297mm'],
    legal: ['8.5in', '14in']
  };
  const CSS_LENGTH = /^\d+(\.\d+)?(px|in|mm|cm|pt|pc)$/;
  // Unitless "0" is a valid CSS length and the natural way to write
  // margin="0"; normalise it to 0px so max()/calc() (which reject a bare
  // number) keep working.
  const safeLen = (v, fb) => {
    v = (v || '').trim();
    return v === '0' ? '0px' : CSS_LENGTH.test(v) ? v : fb;
  };
  // WebKit (Safari and every iOS browser shell) never repeats a table's
  // thead/tfoot on printed pages (WebKit bug 17205), so the spacer-borne
  // vertical margins of a FLOWING document reach only the first page
  // there. Engine check, not browser check: vendor is 'Apple Computer,
  // Inc.' exactly for WebKit and 'Google Inc.' for Blink.
  const WK_PRINT = /apple/i.test(navigator.vendor || '');
  // CSS length → px number (CSS absolute units are exact: 1in = 96px).
  // Returns NaN for anything safeLen would reject — callers gate on it.
  const PX_PER = {
    px: 1,
    in: 96,
    mm: 96 / 25.4,
    cm: 96 / 2.54,
    pt: 96 / 72,
    pc: 16
  };
  const toPx = v => {
    const m = /^(\d+(?:\.\d+)?)(px|in|mm|cm|pt|pc)$/.exec((v || '').trim());
    return m ? parseFloat(m[1]) * PX_PER[m[2]] : NaN;
  };
  const stylesheet = `
    :host {
      position: relative;
      display: block;
      /* When the viewport is narrower than the page, grow to wrap the
       * sheet (plus this padding) instead of staying viewport-width, so
       * the desk background and right margin reach the sheet's far edge
       * in the horizontal scroll. */
      min-width: max-content;
      min-height: 100vh;
      background: #f5f5f4;
      padding: 48px 24px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif;
      --doc-page-w: 8.5in;
      --doc-page-h: 11in;
      --doc-page-margin: 0.75in;
      --doc-hdr-h: 0px;
      --doc-ftr-h: 0px;
      --doc-hdr-pad: 0px;
      --doc-ftr-pad: 0px;
    }
    .sheet {
      width: var(--doc-page-w);
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 10px rgba(20, 20, 19, 0.12);
      border-radius: 7px;
      box-sizing: border-box;
      padding: var(--doc-page-margin);
    }
    .frame { width: 100%; border-collapse: collapse; }
    /* Scaled-fit mode (content-width/content-height): the inner .fit box
     * lays the content out at its authored fixed size and scales it onto
     * the printable area; .fit-box reserves the scaled footprint in flow
     * (transforms don't affect layout) and centers it. Without the mode,
     * both divs are unstyled block pass-throughs. */
    /* Explicit pagination: direct .page children are the pages. The sheet
     * becomes a transparent stack and each page carries the card look on
     * screen; at print each page is exactly one full-bleed sheet. The
     * ::slotted defaults are deliberately weak (document CSS wins), so
     * authored page styling can override any of this. */
    .sheet.paginated {
      background: transparent;
      box-shadow: none;
      border-radius: 0;
      padding: 0;
    }
    .paginated ::slotted(.page) {
      position: relative;
      display: block;
      width: 100%;
      aspect-ratio: var(--doc-page-ar);
      container-type: size;
      overflow: hidden;
      box-sizing: border-box;
      background: #fff;
      border-radius: 7px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
      print-color-adjust: exact;
      -webkit-print-color-adjust: exact;
      break-inside: avoid;
    }
    .paginated ::slotted(.page:not(:first-child)) { margin-top: 1rem; }
    @media print {
      .sheet.paginated { padding: 0; }
      /* The flowing-document vertical inset lives on the repeating
       * thead/tfoot spacers, not the sheet padding — they must go too,
       * or each full-sheet .page is pushed ~margin down and spills onto
       * a second sheet. Paginated pages are full-bleed by definition
       * (content owns its insets). */
      .sheet.paginated .hdr-space,
      .sheet.paginated .ftr-space { height: 0; }
      .paginated ::slotted(.page) {
        border-radius: 0 !important;
        box-shadow: none !important;
        margin: 0 !important;
        /* Physical page-box sizing, no viewport units: Safari resolves
         * 100vh against the window, not the page box, so a vh-sized card
         * paginates wrong there. --doc-page-w/h are the named size by
         * default and are overridden to the user's chosen paper by the
         * export path, so every card is exactly one sheet either way.
         * Width + height (same source values as @page size) rather than
         * width + aspect-ratio: the ratio is a 6-decimal rounding of the
         * same division, and a few millionths of overflow would spill a
         * blank sheet after every page. The screen-only aspect-ratio
         * (preview proportions) must not leak into print. cqh typography
         * tracks the same box.
         *
         * Every declaration is !important: per CSS Scoping, unimportant
         * shadow ::slotted rules LOSE to the document context, so a page
         * section's authored inline style would silently beat this print
         * geometry. A model-authored height:100% did exactly that — the
         * percentage resolves as auto in the all-auto print ancestry, the
         * base rule's size containment turns auto into ZERO, and
         * overflow:hidden then paints nothing: a blank PDF with perfect
         * page boxes. At print the component's geometry is the design's
         * whole contract, so it must win over any authored sizing. */
        aspect-ratio: auto !important;
        width: var(--doc-page-w) !important;
        height: var(--doc-page-h) !important;
        overflow: hidden !important;
      }
      .paginated ::slotted(.page:not(:first-child)) {
        break-before: page !important;
        margin-top: 0 !important;
      }
    }
    .fit-mode .fit-box {
      width: calc(var(--doc-fit-w) * var(--doc-fit-scale));
      height: calc(var(--doc-fit-h) * var(--doc-fit-scale));
      margin: 0 auto;
      break-inside: avoid;
    }
    .fit-mode .fit {
      width: var(--doc-fit-w);
      height: var(--doc-fit-h);
      transform: scale(var(--doc-fit-scale));
      transform-origin: top left;
    }
    .frame td, .frame th { padding: 0; text-align: left; font-weight: inherit; }
    .hdr-space { height: var(--doc-hdr-h); }
    .ftr-space { height: var(--doc-ftr-h); }
    ::slotted([slot="header"]),
    ::slotted([slot="footer"]) { display: block; box-sizing: border-box; }
    @media print {
      :host { background: none; padding: 0; min-width: 0; min-height: 0; }
      .sheet {
        width: auto; margin: 0; box-shadow: none; border-radius: 0;
        padding: 0 var(--doc-page-margin);
      }
      /* The thead/tfoot spacers repeat on every page, so they carry the
       * vertical page margin (which the sheet's own padding cannot, since
       * that padding is consumed once on the first/last page). The running
       * header/footer are fixed inside that band. */
      /* The 0.35in is breathing room between a running header/footer and
       * the body; without one the spacer is exactly the page margin, so a
       * margin="0" full-bleed document gets truly full-bleed pages. */
      .hdr-space { height: max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))); }
      .ftr-space { height: max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))); }
      /* WebKit flowing documents: @page carries the vertical margin (see
       * _syncPrintPageRule), so the spacers keep only whatever a running
       * header/footer needs BEYOND it — page 1 would otherwise double its
       * top inset. Paginated sheets already zero their spacers above. */
      .sheet.wk-print:not(.paginated) .hdr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))) - var(--doc-page-margin))); }
      .sheet.wk-print:not(.paginated) .ftr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))) - var(--doc-page-margin))); }
      ::slotted([slot="header"]) {
        position: fixed; top: 0; left: 0; right: 0; margin: 0;
        padding: calc(var(--doc-page-margin) * 0.45) var(--doc-page-margin) 0;
      }
      ::slotted([slot="footer"]) {
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0;
        padding: 0 var(--doc-page-margin) calc(var(--doc-page-margin) * 0.45);
      }
    }
  `;
  class DocPage extends HTMLElement {
    static get observedAttributes() {
      return ['size', 'width', 'height', 'margin', 'orientation', 'content-width', 'content-height'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._mo = typeof MutationObserver === 'function' ? new MutationObserver(() => this._scheduleMeasure()) : null;
    }

    /** The named paper's [w, h], swapped when orientation="landscape".
     *  Only the named size swaps — explicit width/height are exact values
     *  the author already oriented. */
    _paperSize() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()] || PAPER.letter;
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? [named[1], named[0]] : named;
    }
    get pageWidth() {
      return safeLen(this.getAttribute('width'), this._paperSize()[0]);
    }
    get pageHeight() {
      return safeLen(this.getAttribute('height'), this._paperSize()[1]);
    }
    get pageMargin() {
      return safeLen(this.getAttribute('margin'), '0.75in');
    }

    /** Scaled-fit mode's content box [w, h] as CSS lengths, or null when
     *  the mode is off (either attribute missing/invalid/zero — a partial
     *  declaration falls back to normal flow rather than guessing). */
    _contentFit() {
      const w = safeLen(this.getAttribute('content-width'), null);
      const h = safeLen(this.getAttribute('content-height'), null);
      if (!w || !h) return null;
      const wPx = toPx(w),
        hPx = toPx(h);
      return wPx > 0 && hPx > 0 ? [w, h, wPx, hPx] : null;
    }
    connectedCallback() {
      if (!this._sheet) this._render();
      this._syncSize();
      this._syncPrintPageRule();
      this._ensureTextWrapDefaults();
      this._ensureOwnsPrintMeta();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      if (this._mo) this._mo.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      this._onResize = () => this._scheduleMeasure();
      window.addEventListener('resize', this._onResize);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => this._scheduleMeasure());
      }
      this._scheduleMeasure();
    }
    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
      if (this._mo) this._mo.disconnect();
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = null;
      }
      // Drop the head rules when the last doc-page leaves, so a deleted
      // document's @page geometry and text-wrap defaults can't apply to
      // whatever replaces it.
      const survivor = document.querySelector('doc-page');
      if (!survivor) {
        ['doc-page-print', 'doc-page-text-wrap', 'doc-page-owns-print', 'doc-page-fixed-size', 'doc-page-print-sizing'].forEach(id => {
          const tag = document.getElementById(id);
          if (tag) tag.remove();
        });
        // A live deck-stage deferred its own print-sizing meta to ours —
        // hand the page-global meta over so the deck isn't left unmarked.
        const deck = document.querySelector('deck-stage');
        if (deck && typeof deck._ensurePrintSizingMeta === 'function') {
          deck._ensurePrintSizingMeta();
        }
      } else {
        // A departed owner hands each page-global meta to whatever
        // doc-page remains (or it's removed).
        if (typeof survivor._syncFixedSizeMeta === 'function') {
          survivor._syncFixedSizeMeta();
        }
        if (typeof survivor._syncPrintSizingMeta === 'function') {
          survivor._syncPrintSizingMeta();
        }
      }
    }
    attributeChangedCallback() {
      if (!this._sheet) return;
      this._syncSize();
      this._syncPrintPageRule();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      this._scheduleMeasure();
    }
    _render() {
      this._root.innerHTML = `
        <style>${stylesheet}</style>
        <style id="vars"></style>
        <div class="sheet" data-screen-label="Document">
          <table class="frame" role="presentation">
            <thead><tr><th><div class="hdr-space"><slot name="header"></slot></div></th></tr></thead>
            <tbody><tr><td class="body"><div class="fit-box"><div class="fit"><slot></slot></div></div></td></tr></tbody>
            <tfoot><tr><td><div class="ftr-space"><slot name="footer"></slot></div></td></tr></tfoot>
          </table>
        </div>`;
      this._sheet = this._root.querySelector('.sheet');
      this._vars = this._root.getElementById('vars');
    }

    /** Runtime sizing lives in a shadow <style> :host rule, never on the
     *  light-DOM host element, so serialize-persist can't write it back. */
    _syncSize(hdrH, ftrH) {
      // Scaled-fit mode: content at its authored size, scaled onto the
      // printable area (page minus margins on both axes). The factor is a
      // plain number var so calc(length * number) stays valid; 4 decimals
      // keeps the shadow style stable across re-measures. Upscaling is
      // allowed — print transforms are vector, so text and CSS stay crisp
      // (raster images soften, which the catalog bullet warns about).
      const fit = this._contentFit();
      let fitVars = '';
      if (fit) {
        const marginPx = toPx(this.pageMargin) || 0;
        const availW = toPx(this.pageWidth) - 2 * marginPx;
        const availH = toPx(this.pageHeight) - 2 * marginPx;
        const scale = Math.min(availW / fit[2], availH / fit[3]);
        if (scale > 0 && Number.isFinite(scale)) {
          fitVars = '--doc-fit-w:' + fit[0] + ';' + '--doc-fit-h:' + fit[1] + ';' + '--doc-fit-scale:' + scale.toFixed(4) + ';';
        }
      }
      this._sheet.classList.toggle('fit-mode', !!fitVars);
      // Numeric w/h ratio for the paginated page cards' aspect-ratio —
      // aspect-ratio takes a number, not a length ratio, so compute it
      // here (CSS length division isn't portable). 6 decimals keeps the
      // shadow style stable across re-syncs.
      const arW = toPx(this.pageWidth);
      const arH = toPx(this.pageHeight);
      const ar = arW > 0 && arH > 0 ? (arW / arH).toFixed(6) : '0.772727';
      this._vars.textContent = ':host{' + fitVars + '--doc-page-ar:' + ar + ';' + '--doc-page-w:' + this.pageWidth + ';' + '--doc-page-h:' + this.pageHeight + ';' + '--doc-page-margin:' + this.pageMargin + ';' + '--doc-hdr-h:' + (hdrH || 0) + 'px;' + '--doc-ftr-h:' + (ftrH || 0) + 'px;' + '--doc-hdr-pad:' + (hdrH ? '0.35in' : '0px') + ';' + '--doc-ftr-pad:' + (ftrH ? '0.35in' : '0px') + '}';
    }

    /** @page is a no-op inside shadow DOM, so the rule lives in <head>.
     *  Re-appended on every sync so it stays last in source order — the
     *  @page cascade is source-order per descriptor, so this rule wins
     *  over any other @page rule in the document.
     *
     *  The @page SIZE is pinned where the page box IS part of the design:
     *  explicit-fixed-size mode (width + height authored), scaled-fit
     *  mode (the named sheet the fit targets), and explicit pagination
     *  (the named size the cards share — so card and sheet agree on
     *  every print path, and the export path's chosen paper overrides
     *  BOTH with one later rule). For FLOWING documents no paper size is
     *  emitted at all — the true size comes from the user's preference,
     *  injected by the export path or chosen in the print dialog — so a
     *  flowing document never fights the paper it lands on.
     *  margin: 0 is emitted in every mode: it leaves Chrome no margin box
     *  to draw its date/URL/page-count header in, and the visual margin
     *  lives on the sheet's own padding. */
    _syncPrintPageRule() {
      const id = 'doc-page-print';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
      }
      document.head.appendChild(tag);
      // Three print-geometry regimes:
      // - true-size: the page IS the design — pin its exact size.
      // - scaled-fit (content-width/height): the fit factor is computed
      //   against the NAMED paper's printable area, so that paper must
      //   stay pinned or the scaled content overflows a smaller sheet
      //   (the export path re-fits and re-pins at print time on top).
      // - default modes: no paper size — but landscape still needs the
      //   paper-agnostic 'size: landscape' keyword, because the size
      //   descriptor is what carries orientation; without it a landscape
      //   document prints portrait whenever nothing injects a size.
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      // Explicit pagination pins the page box to the SAME values that
      // size the cards (the named size by default, the export path's
      // chosen paper when its later rule overrides both) — card and
      // sheet agree on every print path, and a mismatched real paper
      // shrinks-to-fit in the dialog instead of clipping a Letter card
      // on A4. Declared before the paginated read below so both derive
      // from one check.
      const paginatedNow = this.querySelector(':scope > .page') !== null;
      const sizeDescriptor = this._trueSizePx() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : this._contentFit() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : paginatedNow ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : landscape ? 'size: landscape; ' : '';
      // WebKit never repeats the thead/tfoot spacers that carry a flowing
      // document's vertical page margins (see WK_PRINT above), so pages
      // after the first print edge-to-edge there. Carry the VERTICAL
      // margins on @page for WebKit instead, and the shadow print CSS
      // trims the first-page spacers by the same amount (.sheet.wk-print
      // rules). Horizontal inset stays on the sheet's own padding in
      // every engine. Blink keeps margin: 0 (a nonzero margin there
      // re-opens the box Chrome draws its header furniture in). One cost,
      // learned in testing: Safari's own date/URL headers are a USER
      // dialog setting ("Print headers and footers") that renders in the
      // margin area when room exists — margin: 0 only suppressed it by
      // leaving no room, and no CSS controls it. The export dialog's
      // Safari guide teaches turning the setting off for flowing
      // documents. Explicitly paginated and fixed-size documents keep
      // margin: 0 everywhere: their pages ARE the sheet.
      const wkFlowing = WK_PRINT && !paginatedNow && !this._trueSizePx() && !this._contentFit();
      const marginDescriptor = wkFlowing ? 'margin: ' + this.pageMargin + ' 0; ' : 'margin: 0; ';
      // Shadow-internal marker (never serialized), kept in lockstep with
      // the @page decision above: the print CSS trims the first-page
      // spacers ONLY while @page actually carries the margins — a
      // true-size or scaled-fit sheet keeps margin: 0 and must keep its
      // spacers too. Re-synced here so attribute changes and pagination
      // flips move both together.
      if (this._sheet) this._sheet.classList.toggle('wk-print', wkFlowing);
      tag.textContent = '@page { ' + sizeDescriptor + marginDescriptor + '} ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; height: auto !important; overflow: visible !important; } ' + 'h1,h2,h3,h4,h5,h6 { break-after: avoid; } ' + 'figure,pre,blockquote,img,svg,tr { break-inside: avoid; } ' + 'p,li { orphans: 3; widows: 3; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; ' + 'backdrop-filter: none !important; -webkit-backdrop-filter: none !important; } ' + '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }

    /** Typographic defaults for document text: balance headings, avoid
     *  widowed/orphaned words in body copy (browsers without text-wrap
     *  support drop the declarations). Zero-specificity via :where() so
     *  any text-wrap authored on those elements wins; document-level so the
     *  rules reach the slotted (light DOM) content — shadow styles can't.
     *  data-omelette-injected marks the tag for the host editor to strip
     *  at serialize, so it is never written back as authored source. */
    _ensureTextWrapDefaults() {
      if (document.getElementById('doc-page-text-wrap')) return;
      const tag = document.createElement('style');
      tag.id = 'doc-page-text-wrap';
      tag.setAttribute('data-omelette-injected', '');
      tag.textContent = ':where(h1,h2,h3,h4,h5,h6){text-wrap:balance}' + ':where(p,li,blockquote,figcaption){text-wrap:pretty}';
      document.head.appendChild(tag);
    }

    /** Declares that this document owns its print CSS. The instant-PDF
     *  export checks for the meta by NAME PRESENCE alone (content is
     *  ignored) and skips its automatic print-CSS injections, so the
     *  component's @page geometry is never overridden by a heuristic.
     *  data-omelette-injected keeps it out of serialized source. */
    _ensureOwnsPrintMeta() {
      if (document.getElementById('doc-page-owns-print')) return;
      const tag = document.createElement('meta');
      tag.id = 'doc-page-owns-print';
      tag.name = 'omelette-owns-print';
      tag.content = 'true';
      tag.setAttribute('data-omelette-injected', '');
      document.head.appendChild(tag);
    }

    /** This page's valid true-size page box (explicit width AND height)
     *  as [w, h] px ints, or null when the mode is off. */
    _trueSizePx() {
      if (!safeLen(this.getAttribute('width'), null) || !safeLen(this.getAttribute('height'), null)) return null;
      const w = Math.round(toPx(this.pageWidth));
      const h = Math.round(toPx(this.pageHeight));
      return w > 0 && h > 0 ? [w, h] : null;
    }

    /** True-size pages (explicit width AND height) also declare the page
     *  box as the preview size: the in-app preview reads
     *  meta[name="omelette-fixed-size"] (content "W,H" in px ints) and
     *  scales the sheet into view — without it an 18in poster previews at
     *  true size with scrollbars. Never overrides an author-set meta
     *  (only the component's own id is managed). The meta is page-global
     *  while doc-page instances are not, so every sync recomputes the
     *  page-wide owner — the first connected true-size doc-page — and a
     *  non-true-size sibling's sync can never delete the owner's meta.
     *  Removed when no true-size page remains (the owner's disconnect
     *  re-syncs via any survivor) or when an author-set meta exists. */
    _syncFixedSizeMeta() {
      const id = 'doc-page-fixed-size';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-fixed-size"]:not([data-omelette-injected])');
      // The page-wide owner, not this instance: an upgraded true-size page
      // anywhere in the document keeps the meta alive and sized.
      let box = null;
      for (const el of document.querySelectorAll('doc-page')) {
        box = typeof el._trueSizePx === 'function' ? el._trueSizePx() : null;
        if (box) break;
      }
      if (!box || authored) {
        if (own) own.remove();
        return;
      }
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-fixed-size';
      tag.content = box[0] + ',' + box[1];
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }

    /** This page's print-sizing mode: 'fixed' when an explicit width AND
     *  height are authored (the page is the design's own size), else the
     *  default paper in the authored orientation. */
    _printSizingMode() {
      if (this._trueSizePx()) return 'fixed';
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? 'default-landscape' : 'default-portrait';
    }

    /** Announces the print-sizing mode to the host app:
     *  meta[name="omelette-print-sizing"] with content 'default-portrait',
     *  'default-landscape', or 'fixed' (fixed pages also carry the
     *  omelette-fixed-size meta with the page box in px). The export path
     *  probes it to decide what true paper size to inject at print time —
     *  in the default modes the component emits no paper size of its own.
     *  Same page-global ownership rules as the fixed-size meta above:
     *  first connected doc-page owns it, an authored meta is never
     *  overridden, removed when no doc-page remains. */
    _syncPrintSizingMeta() {
      const id = 'doc-page-print-sizing';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-print-sizing"]:not([data-omelette-injected])');
      // A fixed page wins outright (mirroring the fixed-size loop above,
      // so the two metas can never contradict each other in a mixed
      // multi-page document); otherwise the first page's mode holds.
      let mode = null;
      for (const el of document.querySelectorAll('doc-page')) {
        if (typeof el._printSizingMode !== 'function') continue;
        const m = el._printSizingMode();
        if (m === 'fixed') {
          mode = m;
          break;
        }
        if (mode === null) mode = m;
      }
      if (!mode || authored) {
        if (own) own.remove();
        return;
      }
      // A deck-stage that connected first injected its own meta and
      // defers to any existing one — take it over, or the document ends
      // up with two conflicting injected metas (a doc-page page is the
      // document; the deck re-ensures its meta if every doc-page leaves).
      const deckMeta = document.getElementById('deck-stage-print-sizing');
      if (deckMeta) deckMeta.remove();
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-print-sizing';
      tag.content = mode;
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }
    _scheduleMeasure() {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this._measure();
      });
    }

    /** Slot heights feed the print spacers (--doc-hdr-h / --doc-ftr-h), so
     *  they re-measure on content mutation, resize, and font load. The
     *  same pass detects explicit pagination (direct .page children) and
     *  toggles the sheet between the flowing-document card and the
     *  page-per-card stack — content edits can add or remove pages at any
     *  time, so this tracks the same mutations the measurement does. */
    _measure() {
      const hdr = this.querySelector(':scope > [slot="header"]');
      const ftr = this.querySelector(':scope > [slot="footer"]');
      const wasPaginated = this._sheet.classList.contains('paginated');
      this._sheet.classList.toggle('paginated', this.querySelector(':scope > .page') !== null);
      // The WebKit @page margin is flowing-only, so a pagination flip
      // must re-emit the rule (content edits can add or remove .page
      // sections at any time).
      if (this._sheet.classList.contains('paginated') !== wasPaginated) {
        this._syncPrintPageRule();
      }
      this._syncSize(hdr ? hdr.offsetHeight : 0, ftr ? ftr.offsetHeight : 0);
    }
  }
  if (!customElements.get('doc-page')) {
    customElements.define('doc-page', DocPage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "doc-page.js", error: String((e && e.message) || e) }); }

// ui_kits/admin_console/Login.jsx
try { (() => {
const {
  Button,
  Input,
  Checkbox,
  Icon,
  Badge
} = window.PhontusDesignSystem_6af7fc;
function Login({
  onSubmit
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      background: 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      placeItems: 'center',
      padding: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 380,
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/phontus-lockup.svg",
    alt: "Phontus",
    style: {
      height: 28,
      justifySelf: 'start'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--weight-bold) var(--text-2xl)/1.2 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Sign in"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-tertiary)'
    }
  }, "Use your work account. Single sign-on is available for enterprise plans.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    iconLeft: "mail",
    placeholder: "you@hospital.org",
    defaultValue: "a.nunez@mercyhealth.org"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    type: "password",
    iconLeft: "lock",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Keep me signed in on this computer",
    checked: true
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: onSubmit
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    fullWidth: true,
    iconLeft: "building-2"
  }, "Continue with SSO")), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "Trouble signing in? ", /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Contact your administrator")))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 520,
      background: 'var(--green-900)',
      color: 'var(--white)',
      display: 'grid',
      alignContent: 'center',
      gap: 'var(--space-6)',
      padding: 'var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/phontus-bridge.svg",
    alt: "",
    style: {
      width: 96,
      opacity: 0.95
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--weight-bold) var(--text-2xl)/1.25 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)',
      textWrap: 'pretty'
    }
  }, "Every conversation understood \u2014 in the room, on the phone, at the counter."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, ['140+ languages, on demand', 'AI interpreting in about 1.4 seconds', 'Certified human interpreters when it matters'].map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center',
      font: 'var(--type-body)',
      color: 'rgba(255,255,255,.86)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 18,
    color: "var(--green-400)"
  }), t)))));
}
Object.assign(window, {
  Login
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin_console/Login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin_console/Overview.jsx
try { (() => {
const {
  StatCard,
  Card,
  DataTable,
  Badge,
  Button,
  StatusIndicator,
  Icon,
  AudioMeter
} = window.PhontusDesignSystem_6af7fc;
const LIVE = [{
  id: 'SSN-40912',
  site: 'Emergency Dept.',
  lang: 'Haitian Creole ⇄ English',
  dur: '04:12',
  state: 'listening'
}, {
  id: 'SSN-40913',
  site: 'Admissions',
  lang: 'Spanish (US) ⇄ English',
  dur: '01:47',
  state: 'interpreting'
}, {
  id: 'SSN-40914',
  site: 'Pharmacy',
  lang: 'Somali ⇄ English',
  dur: '00:39',
  state: 'human'
}];
function Bars() {
  const data = [42, 55, 48, 61, 74, 69, 88, 76, 92, 81, 96, 71];
  const max = Math.max(...data);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 8,
      height: 132
    }
  }, data.map((v, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      display: 'grid',
      gap: 6,
      justifyItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: v / max * 112,
      background: i === data.length - 1 ? 'var(--yellow-300)' : 'var(--green-600)',
      borderRadius: 'var(--radius-xs)',
      opacity: i === data.length - 1 ? 1 : 0.9
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, String(i * 2).padStart(2, '0')))));
}
function Overview({
  onOpenSession
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Sessions today",
    value: "1,284",
    delta: "+12%",
    deltaTone: "up",
    icon: "radio",
    caption: "vs. same day last week"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Median connect",
    value: "1.4",
    unit: "s",
    delta: "-0.2s",
    deltaTone: "up",
    icon: "timer",
    caption: "AI interpreter"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Human escalations",
    value: "37",
    delta: "+4",
    deltaTone: "down",
    icon: "user-round",
    caption: "2.9% of sessions"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Minutes used",
    value: "18,402",
    unit: "/ 25,000",
    icon: "chart-no-axes-column",
    caption: "Renews Sept 1"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Sessions by hour",
    subtitle: "Today, 00:00\u201323:00",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      iconRight: "chevron-down"
    }, "Today")
  }, /*#__PURE__*/React.createElement(Bars, null)), /*#__PURE__*/React.createElement(Card, {
    title: "Top languages",
    subtitle: "Last 30 days"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, [['Spanish (US)', 46], ['Haitian Creole', 21], ['Somali', 13], ['Vietnamese', 11], ['Arabic (MSA)', 9]].map(([l, p]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: 'var(--type-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", null, l), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, p, "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      background: 'var(--neutral-100)',
      borderRadius: 999
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: p + '%',
      height: '100%',
      background: 'var(--green-600)',
      borderRadius: 999
    }
  }))))))), /*#__PURE__*/React.createElement(Card, {
    padding: "none",
    title: "Live now",
    subtitle: "3 sessions in progress",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      iconLeft: "monitor-dot"
    }, "Open monitor"),
    style: {
      paddingBottom: 0
    }
  }, /*#__PURE__*/React.createElement("div", null, LIVE.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    onClick: () => onOpenSession(s),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)',
      padding: 'var(--space-4) var(--space-5)',
      borderTop: '1px solid var(--border-subtle)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(StatusIndicator, {
    state: s.state
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--type-mono)',
      color: 'var(--text-tertiary)',
      width: 92
    }
  }, s.id), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      width: 150,
      color: 'var(--text-secondary)'
    }
  }, s.site), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      flex: 1
    }
  }, s.lang), /*#__PURE__*/React.createElement(AudioMeter, {
    active: s.state !== 'human',
    tone: s.state === 'interpreting' ? 'accent' : 'brand',
    height: 20,
    bars: 7
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--type-mono)',
      color: 'var(--text-tertiary)'
    }
  }, s.dur), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 16,
    color: "var(--text-muted)"
  }))))));
}
Object.assign(window, {
  Overview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin_console/Overview.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin_console/Records.jsx
try { (() => {
const {
  Card,
  DataTable,
  Badge,
  Button,
  Tabs,
  Tag,
  Input,
  Select,
  Switch,
  TranscriptTurn,
  StatCard,
  Icon,
  IconButton,
  StatusIndicator
} = window.PhontusDesignSystem_6af7fc;
const HISTORY = [{
  id: 'SSN-40908',
  site: 'Emergency Dept.',
  lang: 'Somali ⇄ English',
  mode: 'ai',
  dur: '21:17',
  when: 'Today 09:41'
}, {
  id: 'SSN-40901',
  site: 'Radiology',
  lang: 'Spanish (US) ⇄ English',
  mode: 'human',
  dur: '04:38',
  when: 'Today 08:52'
}, {
  id: 'SSN-40894',
  site: 'Admissions',
  lang: 'Vietnamese ⇄ English',
  mode: 'ai',
  dur: '12:04',
  when: 'Yesterday 17:20'
}, {
  id: 'SSN-40881',
  site: 'Pharmacy',
  lang: 'Arabic (MSA) ⇄ English',
  mode: 'ai',
  dur: '06:55',
  when: 'Yesterday 15:03'
}, {
  id: 'SSN-40877',
  site: 'Emergency Dept.',
  lang: 'Haitian Creole ⇄ English',
  mode: 'human',
  dur: '31:12',
  when: 'Yesterday 11:47'
}];
function History({
  onOpen
}) {
  const [tab, setTab] = React.useState('all');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    iconLeft: "search",
    placeholder: "Search sessions, sites, languages",
    wrapperStyle: {
      width: 320
    }
  }), /*#__PURE__*/React.createElement(Select, {
    options: ['All sites', 'Emergency Dept.', 'Admissions', 'Pharmacy'],
    wrapperStyle: {
      width: 190
    }
  }), /*#__PURE__*/React.createElement(Tabs, {
    variant: "segmented",
    items: [{
      value: 'all',
      label: 'All'
    }, {
      value: 'ai',
      label: 'AI'
    }, {
      value: 'human',
      label: 'Human'
    }],
    value: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "md",
    iconLeft: "download",
    style: {
      marginLeft: 'auto'
    }
  }, "Export CSV")), /*#__PURE__*/React.createElement(DataTable, {
    onRowClick: onOpen,
    columns: [{
      key: 'id',
      label: 'Session',
      mono: true,
      width: 120
    }, {
      key: 'when',
      label: 'Started',
      muted: true,
      width: 140
    }, {
      key: 'site',
      label: 'Site',
      width: 160
    }, {
      key: 'lang',
      label: 'Languages'
    }, {
      key: 'mode',
      label: 'Interpreter',
      width: 130,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        size: "sm",
        tone: r.mode === 'human' ? 'human' : 'brand',
        icon: r.mode === 'human' ? 'user-round' : 'sparkles'
      }, r.mode === 'human' ? 'Human' : 'AI')
    }, {
      key: 'dur',
      label: 'Duration',
      mono: true,
      align: 'right',
      width: 100
    }],
    rows: tab === 'all' ? HISTORY : HISTORY.filter(r => r.mode === tab)
  }));
}
function SessionDetail({
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    iconLeft: "arrow-left",
    onClick: onBack,
    style: {
      justifySelf: 'start'
    }
  }, "All sessions"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 'var(--space-4)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Transcript",
    subtitle: "Haitian Creole \u21C4 English (US) \xB7 18 turns",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      iconLeft: "download"
    }, "Export"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      iconLeft: "mail"
    }, "Send"))
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Clinician",
    language: "English (US)",
    time: "00:12",
    original: "Good morning. What brings you in today?",
    translation: "Bonjou. Kisa ki mennen ou isit la jodi a?"
  }), /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Patient",
    language: "Haitian Creole",
    time: "00:24",
    original: "T\xE8t mwen ap f\xE8 m mal depi twa jou.",
    translation: "I've had a headache for three days."
  }), /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Clinician",
    language: "English (US)",
    time: "00:41",
    original: "Have you taken anything for the pain?",
    translation: "\xC8ske ou te pran yon bagay pou doul\xE8 a?"
  }), /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Patient",
    language: "Haitian Creole",
    time: "00:58",
    source: "human",
    original: "S\xE8lman yon ti asetaminof\xE8n y\xE8 swa.",
    translation: "Only some acetaminophen last night."
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Session"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, [['ID', 'SSN-40912'], ['Site', 'Emergency Dept.'], ['Device', 'KIT-2841'], ['Started', 'Today 09:41'], ['Duration', '04:12'], ['Escalated', '02:14 → human']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      font: 'var(--type-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--text-primary)'
    }
  }, v))))), /*#__PURE__*/React.createElement(Card, {
    title: "Quality"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 16,
    color: "var(--green-700)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)'
    }
  }, "Network stable throughout")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "triangle-alert",
    size: 16,
    color: "var(--yellow-500)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)'
    }
  }, "One 2s reconnect at 03:06")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 16,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)'
    }
  }, "Audio not retained")))))));
}
function Devices() {
  const rows = [{
    id: 'KIT-2841',
    site: 'Emergency Dept.',
    model: 'Phontus Kit 2',
    battery: '84%',
    status: 'online',
    seen: 'Now'
  }, {
    id: 'KIT-2840',
    site: 'Admissions',
    model: 'Phontus Kit 2',
    battery: '61%',
    status: 'online',
    seen: 'Now'
  }, {
    id: 'KIT-2822',
    site: 'Pharmacy',
    model: 'Phontus Kit 1',
    battery: '12%',
    status: 'low',
    seen: '3 min ago'
  }, {
    id: 'KIT-2790',
    site: 'Radiology',
    model: 'Phontus Kit 1',
    battery: '—',
    status: 'offline',
    seen: '2 days ago'
  }];
  const tone = {
    online: 'brand',
    low: 'live',
    offline: 'neutral'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Kits deployed",
    value: "28",
    icon: "tablet-smartphone",
    caption: "Across 6 sites"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Online",
    value: "26",
    delta: "93%",
    deltaTone: "neutral",
    icon: "wifi"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Needs attention",
    value: "2",
    icon: "triangle-alert",
    caption: "1 low battery, 1 offline"
  })), /*#__PURE__*/React.createElement(DataTable, {
    onRowClick: () => {},
    columns: [{
      key: 'id',
      label: 'Device',
      mono: true,
      width: 120
    }, {
      key: 'site',
      label: 'Site'
    }, {
      key: 'model',
      label: 'Model',
      muted: true
    }, {
      key: 'status',
      label: 'Status',
      width: 130,
      render: r => /*#__PURE__*/React.createElement(Badge, {
        size: "sm",
        tone: tone[r.status],
        dot: true
      }, r.status === 'online' ? 'Online' : r.status === 'low' ? 'Low battery' : 'Offline')
    }, {
      key: 'battery',
      label: 'Battery',
      mono: true,
      align: 'right',
      width: 90
    }, {
      key: 'seen',
      label: 'Last seen',
      muted: true,
      align: 'right',
      width: 120
    }],
    rows: rows
  }));
}
function Settings() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Interpreting defaults",
    subtitle: "Applied to every new session in this organisation"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Default staff language",
    options: ['English (US)', 'English (UK)', 'French (CA)']
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-label)',
      color: 'var(--text-secondary)'
    }
  }, "Enabled languages"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, ['Spanish (US)', 'Haitian Creole', 'Somali', 'Vietnamese', 'Arabic (MSA)', 'Mandarin'].map(l => /*#__PURE__*/React.createElement(Tag, {
    key: l,
    selected: true,
    onRemove: () => {}
  }, l)), /*#__PURE__*/React.createElement(Tag, {
    icon: "plus"
  }, "Add language"))), /*#__PURE__*/React.createElement(Switch, {
    label: "Allow human escalation",
    description: "Staff can request a certified interpreter mid-session.",
    checked: true
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Retain transcripts for 30 days",
    description: "Audio is never stored.",
    checked: true
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Require session PIN on shared kits",
    checked: false
  }))));
}
Object.assign(window, {
  History,
  SessionDetail,
  Devices,
  Settings
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin_console/Records.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin_console/Shell.jsx
try { (() => {
const {
  SidebarNav,
  TopBar,
  Button,
  Badge,
  Icon,
  IconButton
} = window.PhontusDesignSystem_6af7fc;
const NAV = [{
  value: 'overview',
  label: 'Overview',
  icon: 'layout-dashboard'
}, {
  value: 'sessions',
  label: 'Live sessions',
  icon: 'radio',
  badge: 3
}, {
  value: 'history',
  label: 'History',
  icon: 'history'
}, {
  group: 'Manage'
}, {
  value: 'devices',
  label: 'Devices & kits',
  icon: 'tablet-smartphone'
}, {
  value: 'people',
  label: 'People',
  icon: 'users'
}, {
  value: 'languages',
  label: 'Languages',
  icon: 'languages'
}, {
  group: 'Account'
}, {
  value: 'usage',
  label: 'Usage & billing',
  icon: 'chart-no-axes-column'
}, {
  value: 'settings',
  label: 'Settings',
  icon: 'settings'
}];
function Shell({
  view,
  onView,
  title,
  subtitle,
  breadcrumbs,
  actions,
  children,
  tabs
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      background: 'var(--surface-canvas)'
    }
  }, /*#__PURE__*/React.createElement(SidebarNav, {
    logoSrc: "../../assets/phontus-lockup.svg",
    orgName: "Mercy Health",
    items: NAV,
    value: view,
    onChange: onView,
    footer: /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '10px 12px',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-card)',
        background: 'var(--neutral-25)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 32,
        height: 32,
        display: 'grid',
        placeItems: 'center',
        borderRadius: 'var(--radius-pill)',
        background: 'var(--green-900)',
        color: 'var(--white)',
        font: 'var(--weight-bold) var(--text-2xs)/1 var(--font-sans)'
      }
    }, "AN"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-label)',
        fontSize: 'var(--text-xs)'
      }
    }, "Ana N\xFA\xF1ez"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--type-caption)',
        color: 'var(--text-muted)'
      }
    }, "Administrator")), /*#__PURE__*/React.createElement(IconButton, {
      icon: "chevron-right",
      label: "Account",
      size: "sm",
      style: {
        marginLeft: 'auto'
      }
    }))
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopBar, {
    breadcrumbs: breadcrumbs,
    title: title,
    subtitle: subtitle,
    actions: actions
  }), tabs && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 var(--space-8)',
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, tabs), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: 'var(--space-8)'
    }
  }, children)));
}
Object.assign(window, {
  Shell,
  NAV
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin_console/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/interpreter_console/ActiveCall.jsx
try { (() => {
const {
  Card,
  Button,
  IconButton,
  Badge,
  StatusIndicator,
  AudioMeter,
  TranscriptTurn,
  Tag,
  Icon,
  Input,
  LanguagePair
} = window.PhontusDesignSystem_6af7fc;
function ActiveCall({
  onEnd,
  muted,
  onMute
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 340px',
      gap: 'var(--space-4)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(StatusIndicator, {
    state: muted ? 'muted' : 'listening',
    size: "lg"
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--weight-medium) var(--text-lg)/1 var(--font-mono)',
      color: 'var(--text-secondary)'
    }
  }, "02:41"), /*#__PURE__*/React.createElement(AudioMeter, {
    active: !muted,
    height: 28,
    bars: 11
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: muted ? 'mic-off' : 'mic',
    label: "Mute",
    variant: "secondary",
    size: "lg",
    shape: "circle",
    active: muted,
    onClick: onMute
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "pause",
    label: "Hold",
    variant: "secondary",
    size: "lg",
    shape: "circle"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    size: "lg",
    iconLeft: "phone-off",
    onClick: onEnd
  }, "Leave call")))), /*#__PURE__*/React.createElement(Card, {
    title: "Live transcript",
    subtitle: "Haitian Creole \u21C4 English (US)",
    actions: /*#__PURE__*/React.createElement(Badge, {
      tone: "human",
      icon: "user-round"
    }, "You are interpreting")
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Clinician",
    language: "English (US)",
    time: "02:02",
    original: "I'd like to check your blood pressure now.",
    translation: "Mwen ta renmen tcheke tansyon ou kounye a.",
    source: "human"
  }), /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Patient",
    language: "Haitian Creole",
    time: "02:18",
    original: "\xC8ske sa ap f\xE8 m mal?",
    translation: "Will it hurt?",
    source: "human"
  }), /*#__PURE__*/React.createElement(TranscriptTurn, {
    size: "lg",
    speaker: "Clinician",
    language: "English (US)",
    time: "02:35",
    original: "Not at all \u2014 it just squeezes your arm for a moment.",
    translation: "Non menm \u2014 li jis peze bra ou pou yon moman.",
    source: "human",
    pending: true
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Session context"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, [['Customer', 'Mercy Health'], ['Site', 'Emergency Dept.'], ['Device', 'KIT-2841'], ['Escalated at', '02:14'], ['AI handled', '00:00 – 02:14']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      font: 'var(--type-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, v))))), /*#__PURE__*/React.createElement(Card, {
    title: "Glossary",
    subtitle: "Customer-approved terms"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, ['tansyon — blood pressure', 'sal dijans — emergency room', 'asetaminofèn — acetaminophen'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement(Card, {
    title: "Notes"
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Note for the record\u2026",
    iconLeft: "pencil"
  }))));
}
function Monitor() {
  const {
    DataTable,
    Badge: B,
    StatusIndicator: S
  } = window.PhontusDesignSystem_6af7fc;
  const rows = [{
    int: 'M. Duval',
    lang: 'Haitian Creole',
    org: 'Mercy Health',
    dur: '02:41',
    state: 'listening'
  }, {
    int: 'A. Farah',
    lang: 'Somali',
    org: 'Northside Schools',
    dur: '11:08',
    state: 'interpreting'
  }, {
    int: '—',
    lang: 'Spanish (US)',
    org: 'Harbor Hotel',
    dur: '01:04',
    state: 'connecting'
  }, {
    int: 'L. Ortega',
    lang: 'Spanish (US)',
    org: 'Mercy Health',
    dur: '06:22',
    state: 'reconnecting'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'state',
      label: 'State',
      width: 170,
      render: r => /*#__PURE__*/React.createElement(S, {
        state: r.state
      })
    }, {
      key: 'lang',
      label: 'Language'
    }, {
      key: 'org',
      label: 'Customer'
    }, {
      key: 'int',
      label: 'Interpreter',
      render: r => r.int === '—' ? /*#__PURE__*/React.createElement(B, {
        size: "sm",
        tone: "live",
        dot: true
      }, "Unassigned") : r.int
    }, {
      key: 'dur',
      label: 'Elapsed',
      mono: true,
      align: 'right',
      width: 100
    }],
    rows: rows,
    onRowClick: () => {}
  }));
}
Object.assign(window, {
  ActiveCall,
  Monitor
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/interpreter_console/ActiveCall.jsx", error: String((e && e.message) || e) }); }

// ui_kits/interpreter_console/Queue.jsx
try { (() => {
const {
  Card,
  Badge,
  Button,
  StatCard,
  DataTable,
  StatusIndicator,
  Icon,
  Switch,
  AudioMeter
} = window.PhontusDesignSystem_6af7fc;
const REQUESTS = [{
  id: 'REQ-8841',
  lang: 'Haitian Creole',
  org: 'Mercy Health · Emergency Dept.',
  wait: '00:12',
  context: 'Headache, 3 days. AI interpreting in progress.'
}, {
  id: 'REQ-8842',
  lang: 'Somali',
  org: 'Northside Schools · Registration',
  wait: '00:38',
  context: 'Enrolment paperwork.'
}, {
  id: 'REQ-8843',
  lang: 'Spanish (US)',
  org: 'Harbor Hotel · Front desk',
  wait: '01:04',
  context: 'Billing dispute.'
}];
function Queue({
  onAccept,
  available,
  onAvailable
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Waiting",
    value: "3",
    icon: "users",
    caption: "Longest 01:04"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Accepted today",
    value: "14",
    delta: "+3",
    deltaTone: "up",
    icon: "phone-incoming"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Minutes interpreted",
    value: "212",
    icon: "timer",
    caption: "Target 240"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Avg. accept time",
    value: "8",
    unit: "s",
    delta: "-2s",
    deltaTone: "up",
    icon: "gauge"
  })), /*#__PURE__*/React.createElement(Card, {
    tone: available ? 'brand' : 'sunken',
    padding: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(StatusIndicator, {
    state: available ? 'listening' : 'muted',
    label: available ? 'Available for requests' : 'Not accepting requests',
    size: "lg"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)',
      flex: 1
    }
  }, "Haitian Creole \xB7 Spanish (US) \xB7 French \u2014 certified, healthcare"), /*#__PURE__*/React.createElement(Switch, {
    label: "",
    checked: available,
    onChange: onAvailable,
    style: {
      minHeight: 'auto'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, REQUESTS.map(r => /*#__PURE__*/React.createElement(Card, {
    key: r.id,
    padding: "md",
    elevation: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4,
      width: 200
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) var(--text-lg)/1.1 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, r.lang), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--type-mono)',
      color: 'var(--text-muted)'
    }
  }, r.id)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-secondary)'
    }
  }, r.org), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, r.context)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4,
      justifyItems: 'end'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)'
    }
  }, "Waiting"), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--weight-medium) var(--text-lg)/1 var(--font-mono)'
    }
  }, r.wait)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconLeft: "phone-incoming",
    onClick: onAccept
  }, "Accept"))))));
}
Object.assign(window, {
  Queue
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/interpreter_console/Queue.jsx", error: String((e && e.message) || e) }); }

// ui_kits/interpreting_app/LiveSession.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  IconButton,
  SessionControl,
  LanguagePair,
  StatusIndicator,
  AudioMeter,
  TranscriptTurn,
  Badge,
  Icon,
  Dialog
} = window.PhontusDesignSystem_6af7fc;
const TURNS = [{
  speaker: 'Clinician',
  language: 'English (US)',
  time: '00:12',
  original: 'Good morning. What brings you in today?',
  translation: 'Bonjou. Kisa ki mennen ou isit la jodi a?'
}, {
  speaker: 'Patient',
  language: 'Haitian Creole',
  time: '00:24',
  original: 'Tèt mwen ap fè m mal depi twa jou.',
  translation: "I've had a headache for three days."
}, {
  speaker: 'Clinician',
  language: 'English (US)',
  time: '00:41',
  original: 'Have you taken anything for the pain?',
  translation: 'Èske ou te pran yon bagay pou doulè a?'
}];
function LiveSession({
  pair,
  state,
  muted,
  elapsed,
  onMute,
  onEnd,
  onEscalate,
  onSwap
}) {
  const listening = state === 'listening' || state === 'interpreting';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-canvas)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: '16px 32px',
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(StatusIndicator, {
    state: state,
    size: "lg"
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--weight-medium) var(--text-lg)/1 var(--font-mono)',
      color: 'var(--text-secondary)'
    }
  }, elapsed), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "brand",
    icon: "sparkles"
  }, "AI interpreter"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconLeft: "user-round",
    onClick: onEscalate
  }, "Request human"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 32px 0'
    }
  }, /*#__PURE__*/React.createElement(LanguagePair, {
    size: "lg",
    from: pair.from,
    to: pair.to,
    onSwap: onSwap,
    active: listening,
    style: {
      width: '100%'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: '8px 32px 24px'
    }
  }, TURNS.map((t, i) => /*#__PURE__*/React.createElement(TranscriptTurn, _extends({
    key: i
  }, t, {
    size: i === TURNS.length - 1 ? 'lg' : 'md',
    pending: i === TURNS.length - 1 && state === 'interpreting'
  })))), /*#__PURE__*/React.createElement("footer", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)',
      padding: '20px 32px',
      background: 'var(--white)',
      borderTop: '1px solid var(--border-subtle)',
      boxShadow: '0 -8px 24px -16px rgba(30,64,56,.2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8,
      justifyItems: 'center',
      width: 132
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: muted ? 'mic-off' : 'mic',
    label: muted ? 'Unmute' : 'Mute',
    variant: "secondary",
    size: "xl",
    shape: "circle",
    active: muted,
    onClick: onMute
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, muted ? 'Muted' : 'Microphone on')), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      gap: 10,
      justifyItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(AudioMeter, {
    active: !muted && listening,
    tone: state === 'interpreting' ? 'accent' : 'brand',
    height: 40,
    bars: 13
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, muted ? 'No audio is being sent' : 'Speak normally — pauses are fine')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8,
      justifyItems: 'center',
      width: 132
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "phone-off",
    label: "End session",
    variant: "danger",
    size: "xl",
    shape: "circle",
    onClick: onEnd
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-tertiary)'
    }
  }, "End session"))));
}
function SessionSummary({
  pair,
  onNew
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'grid',
      placeItems: 'center',
      background: 'var(--surface-canvas)',
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 560,
      display: 'grid',
      gap: 'var(--space-6)',
      justifyItems: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--green-50)',
      color: 'var(--green-700)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 30,
    strokeWidth: 2
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--weight-bold) var(--text-2xl)/1.2 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Session ended"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-tertiary)'
    }
  }, pair.from, " \u21C4 ", pair.to)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 1,
      width: '100%',
      background: 'var(--border-subtle)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden'
    }
  }, [['Duration', '04:12'], ['Turns', '18'], ['Interpreter', 'AI']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      background: 'var(--white)',
      padding: '18px 12px',
      display: 'grid',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) var(--text-xl)/1 var(--font-display)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    iconLeft: "file-text"
  }, "Send transcript"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconLeft: "plus",
    onClick: onNew
  }, "New session")), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "Transcript kept 30 days \xB7 Session ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "SSN-40912"))));
}
function EscalateDialog({
  open,
  onClose,
  onConfirm
}) {
  const {
    Dialog: D,
    Button: B
  } = window.PhontusDesignSystem_6af7fc;
  return /*#__PURE__*/React.createElement(D, {
    open: open,
    tone: "warning",
    title: "Request a human interpreter?",
    description: "A certified Haitian Creole interpreter joins the call. AI interpreting continues until they connect.",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(B, {
      variant: "ghost",
      onClick: onClose
    }, "Keep AI"), /*#__PURE__*/React.createElement(B, {
      variant: "primary",
      iconLeft: "user-round",
      onClick: onConfirm
    }, "Request \u2014 about 45s"))
  });
}
Object.assign(window, {
  LiveSession,
  SessionSummary,
  EscalateDialog
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/interpreting_app/LiveSession.jsx", error: String((e && e.message) || e) }); }

// ui_kits/interpreting_app/StartScreen.jsx
try { (() => {
const {
  Button,
  SessionControl,
  LanguagePair,
  StatusIndicator,
  Badge,
  Icon,
  IconButton
} = window.PhontusDesignSystem_6af7fc;
function KioskFrame({
  children,
  footer
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-canvas)'
    }
  }, children, footer);
}
function KioskHeader({
  right
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: '20px 32px',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/phontus-lockup.svg",
    alt: "Phontus",
    style: {
      height: 24,
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 22,
      background: 'var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)'
    }
  }, "Mercy Health \xB7 Emergency Dept."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, right));
}
function StartScreen({
  pair,
  onSwap,
  onStart,
  onPickLanguage,
  onRequestHuman
}) {
  return /*#__PURE__*/React.createElement(KioskFrame, {
    footer: /*#__PURE__*/React.createElement("footer", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        padding: '16px 32px',
        borderTop: '1px solid var(--border-subtle)',
        background: 'var(--white)',
        font: 'var(--type-caption)',
        color: 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "tablet-smartphone",
      size: 14
    }), /*#__PURE__*/React.createElement("span", {
      className: "mono"
    }, "KIT-2841"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Battery 84%"), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "lock",
      size: 13
    }), "End-to-end encrypted"))
  }, /*#__PURE__*/React.createElement(KioskHeader, {
    right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusIndicator, {
      state: "idle",
      label: "Ready"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "settings",
      label: "Settings"
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      placeItems: 'center',
      padding: '32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-8)',
      justifyItems: 'center',
      width: 640,
      maxWidth: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      justifyItems: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--weight-bold) var(--text-3xl)/1.15 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Start an interpreted conversation"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-tertiary)',
      maxWidth: 460
    }
  }, "Confirm the two languages, then press start. Speak normally \u2014 Phontus interprets both directions.")), /*#__PURE__*/React.createElement(LanguagePair, {
    size: "lg",
    from: pair.from,
    to: pair.to,
    onSwap: onSwap,
    style: {
      width: '100%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: "languages",
    onClick: onPickLanguage
  }, "Change language"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: "user-round",
    onClick: onRequestHuman
  }, "Human interpreter")), /*#__PURE__*/React.createElement(SessionControl, {
    action: "start",
    size: 200,
    caption: "Connects in about 1.4 seconds",
    onClick: onStart
  }))));
}
function LanguageSheet({
  open,
  onClose,
  onPick,
  current
}) {
  const langs = ['Spanish (US)', 'Haitian Creole', 'Vietnamese', 'Somali', 'Arabic (MSA)', 'Mandarin', 'Portuguese (BR)', 'Russian', 'Ukrainian', 'Nepali', 'Amharic', 'ASL — video relay'];
  const [q, setQ] = React.useState('');
  if (!open) return null;
  const shown = langs.filter(l => l.toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 50,
      background: 'var(--scrim)',
      backdropFilter: 'var(--blur-overlay)',
      display: 'flex',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxHeight: '82%',
      background: 'var(--white)',
      borderTopLeftRadius: 'var(--radius-surface)',
      borderTopRightRadius: 'var(--radius-surface)',
      boxShadow: 'var(--shadow-xl)',
      display: 'flex',
      flexDirection: 'column',
      animation: 'phontus-fade-up var(--duration-normal) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: '20px 24px 12px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--type-h2)',
      fontSize: 'var(--text-lg)'
    }
  }, "Patient language"), /*#__PURE__*/React.createElement(IconButton, {
    icon: "x",
    label: "Close",
    onClick: onClose,
    style: {
      marginLeft: 'auto'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 24px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 52,
      padding: '0 14px',
      background: 'var(--neutral-50)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-control)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 20,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Search 140+ languages",
    style: {
      flex: 1,
      border: 0,
      background: 'transparent',
      outline: 'none',
      font: 'var(--type-body-lg)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      overflow: 'auto',
      padding: '0 24px 24px',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8
    }
  }, shown.map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: () => onPick(l),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      minHeight: 'var(--touch-comfortable)',
      padding: '0 16px',
      textAlign: 'left',
      background: l === current ? 'var(--surface-brand-subtle)' : 'var(--white)',
      border: `1px solid ${l === current ? 'var(--green-200)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-control)',
      cursor: 'pointer',
      font: 'var(--weight-medium) var(--text-base)/1 var(--font-sans)',
      color: 'var(--text-primary)'
    }
  }, l === current && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 18,
    color: "var(--green-700)"
  }), l)))));
}
Object.assign(window, {
  StartScreen,
  LanguageSheet,
  KioskFrame,
  KioskHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/interpreting_app/StartScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing_site/Sections.jsx
try { (() => {
const {
  Button,
  Badge,
  Card,
  Icon,
  StatusIndicator,
  AudioMeter,
  LanguagePair,
  TranscriptTurn,
  SessionControl,
  Tag,
  Input
} = window.PhontusDesignSystem_6af7fc;
const MAXW = 1200;
const wrap = {
  maxWidth: MAXW,
  margin: '0 auto',
  padding: '0 40px'
};
function SiteHeader({
  onSignIn
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 30,
      background: 'rgba(255,255,255,.86)',
      backdropFilter: 'saturate(180%) blur(12px)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)',
      height: 72
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/phontus-lockup.svg",
    alt: "Phontus",
    style: {
      height: 24
    }
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)'
    }
  }, ['Platform', 'Industries', 'Devices', 'Security', 'Pricing'].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      font: 'var(--weight-medium) var(--text-sm)/1 var(--font-sans)',
      color: 'var(--text-secondary)',
      textDecoration: 'none'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: onSignIn
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    iconRight: "arrow-right"
  }, "Talk to sales"))));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: '1.05fr .95fr',
      gap: 'var(--space-16)',
      alignItems: 'center',
      padding: '80px 40px 88px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "brand",
    icon: "languages"
  }, "140+ languages, on demand"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--weight-extrabold) var(--text-5xl)/1.05 var(--font-display)',
      letterSpacing: 'var(--tracking-tighter)',
      textWrap: 'balance'
    }
  }, "Real-time interpreting your organisation can rely on"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-tertiary)',
      maxWidth: 480,
      textWrap: 'pretty'
    }
  }, "Phontus interprets spoken conversation in both directions, in about a second and a half. Start a session, speak naturally, and let people understand each other \u2014 with a certified human interpreter one tap away."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right"
  }, "Talk to sales"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    iconLeft: "play"
  }, "See a session")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      paddingTop: 'var(--space-2)'
    }
  }, [['1.4s', 'median connect'], ['99.95%', 'session uptime'], ['30 days', 'transcript retention']].map(([v, k]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--weight-bold) var(--text-lg)/1 var(--font-display)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, v), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, k))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--white)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-surface)',
      boxShadow: 'var(--shadow-xl)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '14px 18px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(StatusIndicator, {
    state: "interpreting"
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      font: 'var(--type-mono)',
      color: 'var(--text-tertiary)'
    }
  }, "02:14"), /*#__PURE__*/React.createElement(AudioMeter, {
    active: true,
    tone: "accent",
    height: 18,
    bars: 7,
    style: {
      marginLeft: 'auto'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 18,
      display: 'grid',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(LanguagePair, {
    from: "English (US)",
    to: "Haitian Creole",
    active: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Clinician",
    language: "English (US)",
    time: "02:02",
    original: "I'd like to check your blood pressure now.",
    translation: "Mwen ta renmen tcheke tansyon ou kounye a."
  }), /*#__PURE__*/React.createElement(TranscriptTurn, {
    speaker: "Patient",
    language: "Haitian Creole",
    time: "02:18",
    original: "\xC8ske sa ap f\xE8 m mal?",
    translation: "Will it hurt?",
    pending: true
  })))))));
}
function Steps() {
  const steps = [{
    icon: 'play',
    t: 'Start a session',
    d: 'Pick the language in words — no menus, no codes. One tap on any kit, tablet, or browser.'
  }, {
    icon: 'audio-lines',
    t: 'Speak naturally',
    d: 'Both sides speak in turn. Phontus interprets in both directions and shows the transcript as it goes.'
  }, {
    icon: 'user-round',
    t: 'Escalate if needed',
    d: 'Bring in a certified human interpreter mid-conversation. The session and transcript continue uninterrupted.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '88px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      maxWidth: 620
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--green-700)'
    }
  }, "How it works"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--weight-bold) var(--text-3xl)/1.1 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Three steps, and nothing to learn")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-4)'
    }
  }, steps.map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: s.t,
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-md)',
      background: 'var(--green-50)',
      color: 'var(--green-700)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.icon,
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-mono)',
      color: 'var(--text-muted)'
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: 'var(--type-h3)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, s.t), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'var(--text-tertiary)',
      textWrap: 'pretty'
    }
  }, s.d))))))));
}
function Industries() {
  const rows = [{
    icon: 'heart-pulse',
    t: 'Healthcare',
    d: 'Intake, consent, discharge instructions'
  }, {
    icon: 'scale',
    t: 'Legal services',
    d: 'Client intake, depositions, filings support'
  }, {
    icon: 'graduation-cap',
    t: 'Education',
    d: 'Enrolment, parent meetings, IEP reviews'
  }, {
    icon: 'concierge-bell',
    t: 'Hospitality',
    d: 'Front desk, housekeeping, guest services'
  }, {
    icon: 'store',
    t: 'Retail',
    d: 'Service counters, returns, warranty'
  }, {
    icon: 'landmark',
    t: 'Government',
    d: 'Benefits, permits, public safety'
  }, {
    icon: 'truck',
    t: 'Logistics',
    d: 'Yard, dock, driver briefings'
  }, {
    icon: 'building-2',
    t: 'Multilingual workplaces',
    d: 'Safety briefings, HR conversations'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '88px 0',
      background: 'var(--white)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-10)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      maxWidth: 620
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--green-700)'
    }
  }, "Where it runs"), /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--weight-bold) var(--text-3xl)/1.1 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "Built for the places conversations actually happen")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '1px',
      background: 'var(--border-subtle)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden'
    }
  }, rows.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.t,
    style: {
      background: 'var(--white)',
      padding: 'var(--space-6)',
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: r.icon,
    size: 22,
    color: "var(--green-700)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-label)',
      fontSize: 'var(--text-base)'
    }
  }, r.t), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, r.d))))));
}
function Platform() {
  const items = [{
    icon: 'tablet-smartphone',
    t: 'Devices and kits',
    d: 'Pre-configured tablets, speakerphones and mounts, managed remotely and shipped ready to use.'
  }, {
    icon: 'layout-dashboard',
    t: 'Administration',
    d: 'Sites, staff accounts, enabled languages, retention rules and usage in one console.'
  }, {
    icon: 'monitor-dot',
    t: 'Operational monitoring',
    d: 'Every live session, wait time and reconnect, visible to supervisors as it happens.'
  }, {
    icon: 'shield-check',
    t: 'Security and compliance',
    d: 'Encrypted in transit and at rest, audio never retained, HIPAA-aligned processes and audit logs.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '88px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-16)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--weight-bold) var(--text-3xl)/1.1 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "One platform, not a collection of tools"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-tertiary)',
      textWrap: 'pretty'
    }
  }, "Interpreting, devices, administration and monitoring are the same system. What your staff use in the room is what your operations team sees on the dashboard."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, ['SOC 2 Type II', 'HIPAA-aligned', 'GDPR', 'SSO / SCIM'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    icon: "shield-check"
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, items.map(i => /*#__PURE__*/React.createElement("div", {
    key: i.t,
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      padding: 'var(--space-4)',
      background: 'var(--white)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-xs)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      flex: '0 0 auto',
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-md)',
      background: 'var(--neutral-50)',
      color: 'var(--green-700)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-label)',
      fontSize: 'var(--text-base)'
    }
  }, i.t), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)'
    }
  }, i.d)))))));
}
function Quote() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--green-900)',
      color: 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '80px 40px',
      display: 'grid',
      gap: 'var(--space-6)',
      justifyItems: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/phontus-bridge.svg",
    alt: "",
    style: {
      width: 64
    }
  }), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      font: 'var(--weight-bold) var(--text-2xl)/1.35 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)',
      maxWidth: 820,
      margin: 0,
      textWrap: 'pretty'
    }
  }, "\u201CBefore Phontus, finding an interpreter took eleven minutes on average. Now the conversation starts while the patient is still sitting down.\u201D"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body)',
      color: 'rgba(255,255,255,.7)'
    }
  }, "Placeholder quote \u2014 replace with an approved customer reference.")));
}
function CTA() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '88px 0',
      background: 'var(--white)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-6)',
      justifyItems: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: 'var(--weight-extrabold) var(--text-4xl)/1.08 var(--font-display)',
      letterSpacing: 'var(--tracking-tighter)',
      maxWidth: 720,
      textWrap: 'balance'
    }
  }, "See a session in your own environment"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-lg)',
      color: 'var(--text-tertiary)',
      maxWidth: 520
    }
  }, "We'll set up a kit for your team, in your languages, on a call that takes twenty minutes."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    placeholder: "you@organisation.org",
    iconLeft: "mail",
    wrapperStyle: {
      width: 300,
      textAlign: 'left'
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: "arrow-right"
  }, "Request a demo"))));
}
function Footer() {
  const cols = [['Platform', ['Interpreting', 'Devices & kits', 'Administration', 'Monitoring', 'Integrations']], ['Industries', ['Healthcare', 'Legal', 'Education', 'Hospitality', 'Government']], ['Company', ['About', 'Careers', 'Press', 'Contact']], ['Trust', ['Security', 'Privacy', 'Accessibility', 'Status']]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--neutral-50)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '56px 40px',
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(4,1fr)',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/phontus-lockup.svg",
    alt: "Phontus",
    style: {
      height: 22,
      justifySelf: 'start'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-tertiary)',
      maxWidth: 260
    }
  }, "Real-time interpreting infrastructure for organisations that cannot afford a misunderstanding.")), cols.map(([t, links]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--type-overline)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-muted)'
    }
  }, t), links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      font: 'var(--type-body-sm)',
      color: 'var(--text-secondary)',
      textDecoration: 'none'
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: '20px 40px',
      display: 'flex',
      gap: 'var(--space-4)',
      font: 'var(--type-caption)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Phontus"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto'
    }
  }, "Terms"), /*#__PURE__*/React.createElement("span", null, "Privacy"), /*#__PURE__*/React.createElement("span", null, "Cookies"))));
}
Object.assign(window, {
  SiteHeader,
  Hero,
  Steps,
  Industries,
  Platform,
  Quote,
  CTA,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing_site/Sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.SESSION_STATES = __ds_scope.SESSION_STATES;

__ds_ns.StatusIndicator = __ds_scope.StatusIndicator;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.SidebarNav = __ds_scope.SidebarNav;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.AudioMeter = __ds_scope.AudioMeter;

__ds_ns.LanguagePair = __ds_scope.LanguagePair;

__ds_ns.SessionControl = __ds_scope.SessionControl;

__ds_ns.TranscriptTurn = __ds_scope.TranscriptTurn;

})();
