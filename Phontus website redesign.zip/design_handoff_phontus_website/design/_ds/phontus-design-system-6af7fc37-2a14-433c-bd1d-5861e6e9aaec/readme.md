# Phontus Design System

Phontus is AI-assisted real-time interpreting infrastructure for businesses and organizations. It lets two people who do not share a language talk to each other through fast, reliable spoken interpretation — in an emergency department, at a school registration desk, at a hotel front desk, on a loading dock.

The platform is one system, not a bundle of apps: AI interpreting, optional escalation to a certified human interpreter, dedicated interpreting devices and kits, customer administration, interpreter and supervisor tools, and operational monitoring.

The product promise is short: **start a session, speak naturally, communicate.**

## Positioning

Phontus is serious communication infrastructure — the thing a hospital, a school district, a Fortune 500 company, a government office or a hotel chain trusts with an important conversation. It is not a translation app. Interfaces stay calm in stressful, time-sensitive environments and must be usable by people who are elderly, standing, stressed, wearing gloves, or working from a wall-mounted tablet.

Design direction: **OpenAI meets Apple, with an enterprise/healthcare influence.** Minimal, refined, extremely clear, spacious, human-centred, premium. Never clinical, robotic or "AI-themed".

## Surfaces the system must serve

1. **Interpreting interface** — the heart of the product (tablet, kit, kiosk, browser).
2. **Customer/admin dashboards** — sites, staff, languages, retention, usage.
3. **Interpreter and supervisor consoles** — request queue, active call, operations monitor.
4. **Device and kit management.**
5. **Session history, transcripts, usage and analytics.**
6. **Authentication and onboarding.**
7. **Marketing / website.**
8. **Future native mobile and tablet.**

## Sources used to build this system

Everything here derives from four brand files the user supplied plus their written brand notes. **No codebase, Figma file, screenshots or slide deck were provided.**

| Source | What it gave us |
| --- | --- |
| `uploads/Phontus Logo.svg` | Primary lockup: bridge mark + wordmark in deep green `#1E4038` |
| `uploads/Phontus Bridge.svg` | Standalone bridge mark with the yellow→mint radial gradients |
| `uploads/Phontus Black.svg` | All-black lockup |
| `uploads/Phontus White.svg` | All-white lockup (for deep-green and photographic backgrounds) |
| Written brand notes (in chat) | Palette roles, tone, accessibility requirements, surface inventory |

Copies live in `assets/`, cropped to their content box (the uploads were padded to 1024×768): `phontus-lockup.svg`, `phontus-lockup-white.svg`, `phontus-lockup-black.svg`, `phontus-bridge.svg`.

**Typeface, confirmed:** **Inter at the 28pt optical size** is the brand family — every weight in the system is a variation of it. Numerals and identifiers use the same family with tabular figures rather than a second typeface.

---

## CONTENT FUNDAMENTALS

**Voice.** Calm, specific, operational. Phontus writes like a competent colleague explaining what is about to happen, not like a marketer and not like a machine. Short declaratives. No exclamation marks. No hedging ("might", "we think").

**Person.** Address the reader as **you**; refer to the product as **Phontus**, not "we" ("Phontus interprets in both directions", not "we translate for you"). "We" is allowed only in sales/marketing commitments where a company is doing something for the customer: "We'll set up a kit for your team."

**Casing.** Sentence case everywhere — headlines, buttons, labels, table headers, menu items. The only uppercase is the 11px overline/eyebrow (`--type-overline`, 0.08em tracking): `SESSIONS TODAY`. Never title case, never ALL CAPS in body copy.

**Button copy.** Verb + object, two or three words, no trailing punctuation: `Start session`, `Request human`, `Send transcript`, `End session`, `Export CSV`. Not `Start!`, not `Click here`, not `Submit`.

**Status copy.** One or two words, present tense, describing what the system is doing right now: `Listening`, `Interpreting`, `Speaking`, `Connecting`, `Reconnecting`, `Muted`, `Session ended`, `Connection lost`. State copy is never a full sentence and never apologises.

**Numbers.** Always concrete and always with a unit or comparison: "about 1.4 seconds", "3 in progress", "18,402 / 25,000 minutes", "Transcript kept 30 days". Approximate values say "about"; never "lightning-fast" or "instant".

**Languages.** Named in words, with the regional qualifier where it matters: `Spanish (US)`, `Haitian Creole`, `Arabic (MSA)`, `Portuguese (BR)`, `ASL — video relay`. Direction is written with `⇄`: `Haitian Creole ⇄ English`. **Never a flag, never a country name, never a language code in user-facing copy** (codes may appear in exports).

**Reassurance beats persuasion.** Where a user might hesitate, state the fact plainly and stop: "Audio is never stored." "Transcript kept 30 days, then deleted." "A certified interpreter joins in about 45 seconds. AI interpreting continues until they connect."

**Empty and error states** say what happened and what to do, in that order, without blame: "Connection lost. Phontus is reconnecting — keep the device where it is." Not "Oops!", not "Something went wrong".

**Emoji: never.** Not in product, not in marketing, not in email. Icons carry that load.

**Sample copy that is on-voice**

> Start an interpreted conversation Confirm the two languages, then press start. Speak normally — Phontus interprets both directions.

> Request a human interpreter? A certified Haitian Creole interpreter joins the call. AI interpreting continues until they connect.

> Before Phontus, finding an interpreter took eleven minutes on average.

**Off-voice, do not write:** "Unlock the power of AI translation ✨", "Say goodbye to language barriers!", "Our revolutionary platform", "Let's get you set up!"

---

## VISUAL FOUNDATIONS

### Colour

The identity is **green with yellow as a signal**. Green (`--green-600` for action, `--green-900` for the brand's dark) carries identity, primary actions, success and "listening". Yellow (`--yellow-300`) is reserved for live/active moments, a single highlight, or one emphasis action per screen — it is never a background field, never a surface, never body text on white (it fails contrast; `--yellow-700` is the text-safe stop).

Neutrals are **warm and very slightly green-biased**: canvas `#FAFAF7`, cards pure white, text `#1E1E1B`. Red and a muted blue exist only as semantics — red for destructive/error, blue exclusively for "a human interpreter is involved". Data viz is green-led with one yellow accent; charts never use more than the five `--chart-*` slots.

Light interfaces are the rule. **At most one deep-green (`--green-900`) band per page** — the marketing quote section, the login side panel. Never a dark app chrome.

### Typography

One family does everything: **Inter, 28pt optical size**. 800 for display, 700 for headings, 600 for labels and buttons, 500 for data, 400 for body. Tracking tightens as size grows (`-0.03em` at 60px, `0` at 16px). Body leading 1.45, long-form 1.62, display 1.05–1.2. Tabular figures (`--type-mono`, `.mono`) for anything read as data: session IDs, device IDs, durations, elapsed timers, percentages in tables.

The interpreting screen gets its own step: `--text-session` 34px for the live utterance, 20px for its interpretation. Nothing in the product goes below 12px, and nothing on a session surface below 16px.

Multilingual text expansion is assumed: never fix a label's width, allow two-line buttons on the session surface, and test with Arabic, Devanagari, Cyrillic and Vietnamese diacritics — Inter covers Latin/Cyrillic/Greek; non-Latin scripts fall back to the platform UI font, which is acceptable.

### Backgrounds & imagery

No photography, illustration, texture, pattern or noise is shipped with this system — **none was supplied**. Backgrounds are flat token colours: warm off-white canvas, white cards, one deep-green band. The logo’s radial yellow→mint gradient — the **signal gradient** — is the only gradient in the brand, and it now carries real weight in the identity: see below. Where imagery is eventually needed it should be documentary and warm-neutral — real rooms, real staff, natural light, no cool blue teal grade, no stock-photo handshakes. Marketing pages currently use real product mocks (built from the actual components) instead of art, which is the preferred pattern.

### The signal gradient

Yellow `#FBCE50` blooming into mint `#28E5B0`, sampled from the bridge mark. It is a **light source, not a decoration**: it enters from one corner of a field and fades out. Tokens live in `tokens/gradients.css`:

| Token | Where it belongs |
| --- | --- |
| `--gradient-band` / `--gradient-band-soft` | The deep-green band lit from a corner — the default appearance at scale: marketing bands, login panel, covers, the homepage tile |
| `--gradient-signal` / `--gradient-signal-reverse` | The mark’s own bloom as a plate: app icons, device badges, kit packaging |
| `--gradient-aura` | The halo behind a session control while interpreting |
| `--gradient-rule` | A 2–3px marker: section eyebrows, active tabs, progress tracks |
| `--gradient-whisper` | A barely-there bloom on white: hero backdrops, empty states |

**One gradient moment per screen.** Never a flat wash across a whole screen, never behind body text, never on a card, a filled button, a table or console chrome, never two moments on one screen, and never a hue outside those two stops.

### Layout

Console: 264px sidebar (white, one hairline right border) + 64px top bar + 32px content gutter on a warm canvas. Marketing: 1440px page, 1200px content column, 40px gutters, 88px section rhythm. Interpreting: 1024×768 design target, 32px padding, fixed header and footer bars with the transcript scrolling between them — the primary control is always in the same place, never scrolls away, and the footer bar carries a `0 -8px 24px -16px` upward shadow instead of a hard divider.

Fixed elements: session header/footer, marketing site header (sticky, translucent white with blur — the only blur in the system besides modal scrims), console sidebar and top bar.

### Borders, cards, elevation

Cards are white, `--radius-card` (14px), `1px solid --border-subtle`, `--shadow-sm`. That is the default surface, and it should look almost flat. Shadows are green-tinted (`rgba(30,64,56,…)`), low and soft; `xs`/`sm` cover 90% of cases, `lg`/`xl` are for modals and the marketing hero mock only. Dividers are always 1px `--border-subtle`; grids of tiles are built with 1px gaps over a border-coloured parent so the rules are hairlines. No colored left-border accent cards. No glassmorphism outside the sticky header and modal scrim.

Radii: 4 (checkbox), 6 (chips, small controls), 10 (buttons, inputs), 14 (cards), 20 (modals, session panes), pill (status pills, circular session controls, avatars). Pills are for status and round controls only — a pill is never a normal button.

### States

- **Hover:** one step darker for filled surfaces (`--action-primary` → `--action-primary-hover`), a warm grey wash (`--surface-hover`) for ghost and secondary. Never opacity fades, never lifts on hover except the session hero control (which deepens its shadow).
- **Press:** one step darker again; large session controls also `scale(.975)`. No ripples.
- **Focus:** 2px `--focus-ring` outline with a 2px offset, or `--shadow-focus` on fields. Always visible — keyboard operation is a requirement, not a nicety.
- **Selected:** `--surface-brand-subtle` fill with `--green-200` border and `--green-800` text.
- **Disabled:** `--surface-disabled` fill, `--text-muted` label, no shadow, `not-allowed` cursor. Never below 40% perceived contrast.
- **Live:** colour + written label + motion, always all three. Colour alone never carries a state.

### Motion

Functional only. 140ms for control feedback, 220ms for panels and dialogs, 360ms at most. `--ease-standard: cubic-bezier(.32,.72,0,1)` for entering elements, `--ease-in-out` for loops. Three sanctioned loops: `phontus-pulse` (status dots), `phontus-bar` (audio level bars), `phontus-ring` (live emphasis). Entrances are a 6px rise plus fade (`phontus-fade-up`). No bounce, no spring overshoot, no parallax, no animated illustration. `prefers-reduced-motion` zeroes all durations.

### Transparency & blur

Three places only: the marketing sticky header (`rgba(255,255,255,.86)` + blur), modal scrims (`--scrim` + 8px blur), and inverse-surface controls (`rgba(255,255,255,.12)`). Everything else is opaque.

---

## ICONOGRAPHY

**Set: [Lucide](https://lucide.dev) (MIT), loaded from CDN — a flagged substitution.** No icon assets were supplied with the brand files. Lucide was chosen because its 24px grid, round caps and even stroke match the wordmark's geometry and the system's restrained tone. If Phontus has its own icon set, replace `components/core/Icon.jsx`'s data source and nothing else changes.

- **Stroke weight 1.75** (never below 1.5 — icons must survive glare, distance and gloved use). Round caps and joins.
- **Sizes:** 16 in dense tables, 20 default, 24 in toolbars and buttons at `lg`, 28–44 on session surfaces.
- Icons inherit `currentColor`; they are never multi-colour, never filled, never boxed in a coloured tile except the 40–44px `--radius-md` "feature" tiles on marketing pages (`--green-50` background, `--green-700` glyph).
- Icons **support** text; they replace it only in `IconButton`, which always carries an `aria-label` and a tooltip.
- **No emoji, ever.** No unicode pictographs as icons. The only non-icon glyphs in use are `⇄` (language direction) and `·` (metadata separator).
- **No flags.** Languages are words.

Canonical glyph vocabulary: `mic` / `mic-off` (microphone), `audio-lines` (interpreting), `volume-2` (speaking), `phone-off` (end session), `phone-incoming` (incoming request), `user-round` (human interpreter), `sparkles` (AI interpreter — the one sanctioned "AI" glyph), `languages`, `arrow-right-left` (swap), `radio` (live session), `history`, `tablet-smartphone` (devices/kits), `monitor-dot` (monitoring), `shield-check` (security), `wifi` (network), `triangle-alert`, `check`, `timer`, `chart-no-axes-column`, `layout-dashboard`, `users`, `settings`.

---

## Index

**Root**

- `styles.css` — the single entry point consumers link. `@import` lines only.
- `thumbnail.html` — homepage tile.
- `readme.md` — this file. `SKILL.md` — Agent Skills wrapper.

**`tokens/`** — `fonts.css` (Inter webfont import + optical-size setting), `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `gradients.css`, `motion.css` (keyframes), `base.css` (resets, link colours).

**`assets/`** — `phontus-lockup.svg`, `phontus-lockup-white.svg`, `phontus-lockup-black.svg`, `phontus-bridge.svg`.

**`guidelines/`** — 20 specimen cards: colour ramps, semantic aliases, session-state palette, the signal gradient, type scales (display, body, session, mono, labels), spacing, touch targets, console layout, radii, elevation, brand lockup, mark, motion, and a "do not" card.

**`components/`** — 24 primitives, each with `.jsx`, `.d.ts`, `.prompt.md`, and one `@dsCard` per directory.

| Group | Components |
| --- | --- |
| `core/` | Icon, Button, IconButton, Card, Badge, Tag |
| `forms/` | Input, Textarea, Select, Checkbox, Radio, Switch |
| `feedback/` | StatusIndicator (+ `SESSION_STATES`), Toast, Tooltip, Dialog |
| `navigation/` | Tabs, SidebarNav, TopBar |
| `session/` | SessionControl, LanguagePair, AudioMeter, TranscriptTurn |
| `data/` | StatCard, DataTable |

**`ui_kits/`**

- `interpreting_app/` — 1024×768 tablet/kiosk: start, language sheet, live session, session ended.
- `admin_console/` — 1440×900 customer console: overview, history, session detail, devices, settings, login.
- `interpreter_console/` — 1440×900 interpreter + supervisor: request queue, active call, operations monitor.
- `marketing_site/` — 1440 homepage: hero, how it works, industries, platform, quote, CTA, footer.

**Root deliverable** — `Phontus Brand Book.html`: the 17-page printable brand book (landscape, letter/A4), built on `doc-page.js`.

### Intentional additions

No source design system defined a component inventory, so the standard primitive set was authored from the brand notes. Five domain components were added because the interpreting screen cannot be built from generic primitives, and building it ad hoc is how state vocabulary drifts:

- **`StatusIndicator` + `SESSION_STATES`** — one canonical definition of the ten live states (colour, surface, label, glyph, pulse). Everything else reads from it.
- **`SessionControl`** — the 176px+ hero action; hierarchy this strong cannot be a `Button` size.
- **`LanguagePair`** — enforces "languages in words, never flags", including the swap affordance.
- **`AudioMeter`** — the proof-of-audio signal, so no screen invents its own.
- **`TranscriptTurn`** — the original/interpretation pair with source attribution, shared between the live screen and history.

### Known gaps

- No photography, no illustration, no customer logos, no approved customer quote (the marketing quote is labelled placeholder).
- People and Usage/billing console views are deliberately left as labelled placeholders — no source design existed to recreate.
- Native mobile/tablet layouts are not drawn; the token set (touch sizes, session type step) is sized for them.
